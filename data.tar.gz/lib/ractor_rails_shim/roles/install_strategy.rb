# frozen_string_literal: true

# InstallStrategy: the composition objects that own the per-mode install
# bodies (Issue #26, POODR §5 Composition).
#
# StorageStrategy was split into ::Ractor/::Thread (storage_strategy.rb)
# — the POODR-correct shape. Installer.install did not get the same
# treatment: it kept an inline `if RactorRailsShim.thread_mode?` with
# two ~20-line bodies. This module extracts those bodies into strategy
# objects so the last `thread_mode?` branch is removed from Installer.
#
# The RactorRailsShim singleton keeps facade methods (install, installed?,
# _install_all_framework_patches) that delegate, so existing specs keep
# passing unchanged.

module RactorRailsShim
  module InstallStrategy
    # Full install for Ractor (Puma/Falcon in Ractor mode, Falcon): all
    # patches that route framework globals through per-Ractor IES.
    module Ractor
      def self.install
        RactorRailsShim.install_mattr_accessor
        # Patch Module#thread_mattr_reader/writer BEFORE any gem loads:
        # the generated methods memoize their IsolatedExecutionState key in
        # a class/module ivar (`@__thread_mattr_#{sym} ||=`), and that
        # write raises IsolationError from a worker Ractor — every request,
        # once a gem like turbo-rails (current_request_id,
        # suppressed_turbo_broadcasts) defines a thread_mattr. The patched
        # macros emit the key without the ivar memo; gem-defined accessors
        # are then generated worker-safe automatically.
        RactorRailsShim.__send__(:_install_thread_mattr_patch)
        # Patch ActiveRecord::SecureToken's `has_secure_token` macro BEFORE any
        # model calls it: upstream registers a BLOCK callback, which
        # SymbolicTransport skips in workers — worker-created rows got a NULL
        # token column (ActiveStorage::Blob#key -> direct uploads died with a
        # NotNullViolation). The patched macro adds an equivalent Symbol
        # callback, so workers generate tokens exactly like main.
        RactorRailsShim.__send__(:_install_secure_token_patch)
        RactorRailsShim.install_class_attribute
        RactorRailsShim.install_zeitwerk_registry
        RactorRailsShim.install_rubygems
        RactorRailsShim.install_rails_module
        RactorRailsShim::ConstantShareabilizer.install
        RactorRailsShim.install_execution_wrapper
        require "active_support/callbacks" rescue nil
        RactorRailsShim::CallbackCapture.install_callback_declaration_capture!
        # Patch the `scope` macro BEFORE the app's models are eager-loaded, so
        # `scope :recent, -> { ... }` compiles a worker-safe (string-eval'd)
        # method instead of Rails' un-shareable define_method. The patch
        # requires active_record itself, so it is safe to call this early —
        # it applies immediately and is idempotent (no-op at prepare time).
        RactorRailsShim.__send__(:_install_activerecord_scope_patch)
        # Patch ActiveRecord reflections BEFORE eager-load: AR memoizes ivars
        # (@foreign_key, @klass, @inverse_of, ...) on reflection objects, but
        # those objects are frozen in the shared app graph, so the write raises
        # FrozenError in workers on the first association read. Route the
        # memoization through a per-worker cache instead.
        RactorRailsShim.__send__(:_install_activerecord_reflection_patch)
        # Patch ActiveStorage's `has_one_attached` / `has_many_attached` BEFORE
        # the app's models eager-load, so the generated `has_one`/`has_many`
        # association scope lambda gets a shareable `self` (ActiveStorage's
        # default scope uses the un-shareable association builder as `self`,
        # which makes `User.reflections` un-shareable and breaks attachment
        # reads in worker Ractors). The patch force-loads the macro module if
        # needed and is idempotent (no-op at prepare time).
        RactorRailsShim.__send__(:_install_active_storage_patch)
        # Patch ActiveRecord::Store#store_accessor BEFORE any model that uses
        # `store` is loaded, so the generated accessors (e.g. ActiveStorage's
        # `identified=`/`analyzed=`/`composed=`) are emitted as string-eval
        # `def`s (shareable) instead of `define_method` blocks. Without this,
        # a worker Ractor raises "defined with an un-shareable Proc".
        RactorRailsShim.__send__(:_install_active_record_store_patch)
        # Patch http_basic_authenticate_with BEFORE the app's controllers are
        # eager-loaded, so the guard is registered as a symbol filter + real
        # def (the upstream block filter is silently no-op'd by proc
        # replacement in worker Ractors — basic auth was skipped entirely).
        RactorRailsShim.__send__(:_install_http_basic_auth_patch)
        # Patch CGI::Escape's class-variable default arguments BEFORE anything
        # URL-decodes in a worker (globalid -> URI::GID -> CGI.unescape):
        # @@accept_charset is a class VARIABLE, and Ruby forbids reading class
        # variables from non-main Ractors outright — even shareable ones.
        RactorRailsShim.__send__(:_install_cgi_patch)
        # Patch Marcel's `EXTENSIONS` table BEFORE eager-load so the frozen,
        # shareable Hash is in place when worker Ractors extract an attachment's
        # content type (ActiveStorage::Blob#extract_content_type -> Marcel).
        RactorRailsShim.__send__(:_install_marcel_patch)
        # Patch ActionView::Base.with_empty_template_cache EARLY (before
        # eager load) so production's DetailsKey.view_context_class uses the
        # block-free version. The framework's original defines
        # compiled_method_container via define_method(&block) — an
        # un-shareable Proc that breaks worker Ractors. on_load fires as
        # soon as ActionView is required, well before the app's eager_load.
        ActiveSupport.on_load(:action_view) do
          RactorRailsShim._install_with_empty_template_cache_patch
          RactorRailsShim._install_action_view_sanitize_patch
          RactorRailsShim._install_loofah_patch
        end
      end
    end

    # Minimal install for thread (Puma/Falcon) servers: only the
    # class_attribute isolation fix + nil-safe callback replay. The
    # other patches route framework globals through per-Ractor IES,
    # which is empty on Puma's request threads and would break the app,
    # so they are skipped; the original Rails globals are thread-safe
    # and used as-is.
    module Thread
      def self.install
        RactorRailsShim.install_class_attribute
        RactorRailsShim.install_execution_wrapper
        # Capture each controller's OWN declared before_action/after_action
        # filters at declaration time (during eager load) by intercepting
        # ActiveSupport::Callbacks.set_callback. This must be installed
        # BEFORE eager load so declarations are captured as they happen —
        # the class_attribute callback chain is corrupted by an eager-load
        # leak under Ruby 4.0.5 + Rails 8.1.3 + Devise, so reading
        # __callbacks later yields a wrong, unshareable chain. Install
        # requires active_support/callbacks to be loaded, so require it
        # first; install runs before the app's eager_load, so every
        # controller declaration is captured.
        require "active_support/callbacks" rescue nil
        RactorRailsShim::CallbackCapture.install_callback_declaration_capture!
      end
    end
  end
end
