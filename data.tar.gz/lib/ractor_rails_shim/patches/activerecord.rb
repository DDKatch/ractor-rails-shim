# frozen_string_literal: true

# Patch ActiveRecord's connection handler to work in per-Ractor mode.
#
# Blocker 1:
#   ActiveRecord::Base.connection_pool calls
#   default_connection_handler.retrieve_connection_pool(...)
#   at connection_handling.rb:346. The default_connection_handler
#   class_attribute is known-unshareable (holds callback chains with
#   self-capturing Procs), so the shim's nil fallback is correct for
#   callbacks BUT AR needs a live connection pool per worker. DB connections
#   can't cross Ractor boundaries.
#
# Fix: Each worker Ractor gets its own ConnectionHandler with its own pool,
# seeded from the same db config as main. We patch `connection_handler` /
#   `connection_handler=` / `default_connection_handler` to use per-Ractor
#   storage (IES), and provide a worker-init hook that creates a new
#   ConnectionHandler + establishes a connection from the same pool spec.
#
# Rails already uses IES for `connection_handler` (core.rb:132-138):
#   def self.connection_handler
#     RactorRailsShim.storage[:active_record_connection_handler] || default_connection_handler
#   end
#   def self.connection_handler=(handler)
#     RactorRailsShim.storage[:active_record_connection_handler] = handler
#   end
#
# The problem: in the main ractor, `default_connection_handler` is set via
# class_attribute (core.rb:97+248). In a worker ractor, the shim's
# class_attribute patch returns nil for default_connection_handler (it's
# in the known-unshareable skip list). So connection_handler returns nil,
# and `connection_pool` raises NoMethodError on nil.
#
# The fix: in each worker, call RactorRailsShim.init_worker_ar_connections!
# which creates a fresh ConnectionHandler and establishes connections from
# the same configurations as main. The handler is stored in IES (which
# Rails already reads). We also capture the pool spec (db configs) in the
# main ractor at prepare_for_ractors! time as a shareable constant so workers
# can read it.

module RactorRailsShim
  # ActiveRecord holds several mutable container constants (Arrays / Sets of
  # symbols) that are read during query execution (unscope, order, etc.).
  # Reading them from a worker Ractor raises Ractor::IsolationError
  # ("can not access non-shareable objects in constant ..."). Register them so
  # the shim deep-freezes + const_set's a shareable twin at prepare time.
  SHAREABLE_CONSTANTS.concat([
    "ActiveRecord::QueryMethods::VALID_UNSCOPING_VALUES",
    "ActiveRecord::QueryMethods::VALID_DIRECTIONS",
    "ActiveRecord::Relation::MULTI_VALUE_METHODS",
    "ActiveRecord::Relation::SINGLE_VALUE_METHODS",
    "ActiveRecord::Relation::VALUE_METHODS",
    "ActiveRecord::Relation::CLAUSE_METHODS",
    "ActiveRecord::Relation::INVALID_METHODS_FOR_UPDATE_AND_DELETE_ALL",
    "ActiveRecord::Relation::Merger::NORMAL_VALUES",
    "ActiveRecord::Relation::WhereClause::ARRAY_WITH_EMPTY_STRING",
    "ActiveRecord::AttributeMethods::RESTRICTED_CLASS_METHODS",
    "ActiveRecord::AttributeMethods::PrimaryKey::ClassMethods::ID_ATTRIBUTE_METHODS",
    "ActiveRecord::Callbacks::CALLBACKS",
    "ActiveRecord::ConnectionAdapters::ColumnDefinition::OPTION_NAMES",
    "ActiveRecord::ConnectionAdapters::PostgreSQL::DatabaseStatements::IDLE_TRANSACTION_STATUSES",
    "ActiveRecord::ConnectionAdapters::SQLite3Adapter::DEFAULT_PRAGMAS",
    "ActiveRecord::ConnectionAdapters::SQLite3Adapter::NATIVE_DATABASE_TYPES",
    "ActiveRecord::ConnectionHandling::DEFAULT_ENV",
    "ActiveRecord::ConnectionHandling::RAILS_ENV",
    "ActiveRecord::NestedAttributes::UNASSIGNABLE_KEYS",
    "ActiveRecord::Transactions::ACTIONS",
    "ActiveRecord::LogSubscriber::IGNORE_PAYLOAD_NAMES",
    "ActiveRecord::ExplainRegistry::Subscriber::IGNORED_PAYLOADS",
    "ActiveRecord::StructuredEventSubscriber::IGNORE_PAYLOAD_NAMES",
    "ActiveRecord::Encryption::Context::PROPERTIES",
    "ActiveRecord::Encryption::Encryptor::DECRYPT_ERRORS",
    "ActiveRecord::Encryption::Encryptor::ENCODING_ERRORS",
    "ActiveRecord::Encryption::Properties::ALLOWED_VALUE_CLASSES",
    "ActiveRecord::Encryption::Properties::DEFAULT_PROPERTIES",
    "Arel::SelectManager::STRING_OR_SYMBOL_CLASS",
    "ActiveRecord::Delegation::GeneratedRelationMethods::MUTEX",
  ])

  # Shareable replacements for Arel::Visitors::*::BIND_BLOCK constants.
  # These are Procs (e.g. `proc { |i| "$#{i}" }`) used to format bind
  # parameters in SQL. Procs can't be made shareable. We patch the `bind_block`
  # method to return a shareable Callable instead (defined via string eval,
  # no captured binding).
  class << self
    def _install_arel_bind_block_patch
      return if @arel_bind_block_patched
      @arel_bind_block_patched = true
      _register_patch :arel_bind_block, "8.1"

      # PostgreSQL: proc { |i| "$#{i}" }
      if defined?(::Arel::Visitors::PostgreSQL)
        ::Arel::Visitors::PostgreSQL.module_eval <<-RUBY, __FILE__, __LINE__ + 1
          def bind_block
            RactorRailsShim::PgBindBlock
          end
        RUBY
      end

      # ToSql (base): proc { "?" }
      if defined?(::Arel::Visitors::ToSql)
        ::Arel::Visitors::ToSql.module_eval <<-RUBY, __FILE__, __LINE__ + 1
          def bind_block
            RactorRailsShim::SqlBindBlock
          end
        RUBY
      end
    end
  end

  # Shareable snapshot of each AR model class's primary_key, captured at
  # prepare time. Workers read this instead of the raw @primary_key class ivar
  # (which is initialized to PRIMARY_KEY_NOT_SET, a BasicObject that can't be
  # made shareable). Populated by _share_model_classes! in the main ractor.
  AR_PRIMARY_KEYS_SHAREABLE = Ractor.make_shareable({})

  # Shareable table of `dependent:` associations, captured at prepare time so
  # worker Ractors can replay them. The Rails `dependent: <type>` option
  # registers a LAMBDA `before_destroy` filter
  # (`->(o) { o.association(reflection.name).handle_dependency }`). A lambda is
  # an unshareable Proc, so the model's `__callbacks` chain can't be made
  # Ractor-shareable and workers get an EMPTY destroy chain — meaning dependent
  # children are never deleted/cascade in workers (FK-violation 500). We instead
  # capture (model_name => [{name:, type:, macro:}]) and, in a worker's empty
  # `:destroy` chain, call `record.association(name).handle_dependency` directly
  # (the exact method the original lambda invoked). Entries are Hashes of
  # Symbols/booleans -> natively shareable.
  SHAREABLE_DEPENDENT_ASSOCIATIONS = nil

  # Shareable callable that replaces Arel::Visitors::PostgreSQL::BIND_BLOCK
  # (a Proc `proc { |i| "$#{i}" }`). Callable cross-Ractor.
  PgBindBlock = Ractor.make_shareable(Object.new.tap do |o|
    def o.call(i); "$#{i}"; end
    def o.to_proc; method(:call).to_proc; end
  end)

  # Shareable callable that replaces Arel::Visitors::ToSql::BIND_BLOCK
  # (a Proc `proc { "?" }`). Callable cross-Ractor.
  SqlBindBlock = Ractor.make_shareable(Object.new.tap do |o|
    def o.call(_i = nil); "?"; end
    def o.to_proc; method(:call).to_proc; end
  end)

  # Shareable snapshot of ActiveRecord::Base.configurations at
  # prepare_for_ractors! time. Workers read this to establish their own
  # connection pools with the same db config. Made shareable (frozen).
  AR_CONFIGURATIONS_SNAPSHOT = nil

  # Shareable (deep-frozen) copy of ActiveRecord::Base.configurations (the
  # DatabaseConfigurations object) captured at prepare time. Workers read
  # this instead of the raw `@@configurations` class variable, which a
  # non-main Ractor cannot access.
  AR_CONFIGURATIONS_SHAREABLE = nil

  # Shareable snapshot of every model that owns its own pool (`connects_to`
  # — Solid Cache/Queue/Cable records and app multi-database models), keyed
  # by class name: { "SecondaryRecord" => { config: {...}, shard: :default } }.
  # Captured in main at prepare. Workers cannot re-resolve `connects_to`
  # reliably (a lazily autoloaded class resolved the PRIMARY config), so the
  # worker handler re-establishes these pools from this snapshot under the
  # model's own connection_specification_name.
  AR_CONNECTION_CLASSES_SNAPSHOT = nil

  # Shareable (deep-frozen) copy of DatabaseConfigurations.db_config_handlers
  # (an Array of shareable handler Procs) captured at prepare time. Workers
  # read this instead of the per-Ractor class instance variable.
  AR_DB_CONFIG_HANDLERS_SHAREABLE = nil

  # Shareable (deep-frozen) copy of ActiveRecord.query_transformers (an Array
  # of transformer classes/objects) captured at prepare time. Workers read this
  # instead of the per-Ractor class instance variable.
  AR_QUERY_TRANSFORMERS_SHAREABLE = nil

  # Capture the db configurations from the main ractor at
  # prepare_for_actors! / make_app_shareable! time. This is a shareable
  # snapshot (frozen Hash of config hashes) that workers use to establish
  # their own connection pools. Must run in the main Ractor.
  class << self
    def _capture_ar_configurations!
      return if @_ar_configs_captured
      @_ar_configs_captured = true
      return unless defined?(::ActiveRecord::Base)

      begin
        # Build a plain Hash snapshot of every db config keyed by
        # [env_name][config_name] => config_hash. Use
        # ActiveRecord::Base.configurations.configs_for (returns DbConfig
        # objects with .name, .env_name, .configuration_hash) rather than
        # Rails.application.config.database_configuration (a legacy Hash whose
        # shape differs between single-config apps (flat Hash = the config
        # itself) and multi-config apps (nested Hash of name => config)).
        cfgs = ::ActiveRecord::Base.configurations
        snapshot = {}
        if cfgs.respond_to?(:configs_for)
          cfgs.configs_for.each do |dc|
            env_name = dc.env_name
            name = dc.name || "primary"
            hash = dc.configuration_hash
            next unless hash.is_a?(::Hash)
            snapshot[env_name] ||= {}
            snapshot[env_name][name] = hash.reject { |_k, v| v.nil? }
          end
        end
        # Fallback: legacy database_configuration Hash (env => { name => config }
        # OR env => flat config). Used if configs_for is unavailable.
        if snapshot.empty?
          raw = ::Rails.application.config.database_configuration rescue {}
          raw.each do |env_name, env_configs|
            next unless env_configs.is_a?(::Hash)
            snapshot[env_name] ||= {}
            if env_configs.key?("adapter") || env_configs.key?(:adapter)
              # Flat config: the env value IS the "primary" config itself.
              snapshot[env_name]["primary"] = env_configs.reject { |_k, v| v.nil? }
            else
              # Nested: env => { name => config }
              env_configs.each do |name, config|
                next unless config.is_a?(::Hash)
                snapshot[env_name][name] = config.reject { |_k, v| v.nil? }
              end
            end
          end
        end
        snapshot.freeze
        Ractor.make_shareable(snapshot)
        _reassign_shareable_const(:AR_CONFIGURATIONS_SNAPSHOT, snapshot)
      rescue StandardError => e
        # Best-effort; if we can't capture configs, workers won't be able
        # to auto-init connections. They can call init_worker_ar_connections!
        # manually with explicit configs.
      end
    end

    # Worker-Ractor hook: create a fresh ConnectionHandler and establish
    # connections from the captured configurations snapshot. Call this in
    # each worker Ractor before serving requests:
    #
    #   Ractor.new(app) do |a|
    #     RactorRailsShim.init_worker_ar_connections!
    #     a.call(env)
    #   end
    #
    # Idempotent: safe to call multiple times (subsequent calls are no-ops
    # once the handler is established). Uses Ractor.store_if_absent semantics
    # via IES.
    # Capture (main Ractor, prepare time) every model that owns a pool via
    # `connects_to`, together with the db config main resolved for it. The
    # worker handler re-establishes those pools from this snapshot — see the
    # AR_CONNECTION_CLASSES_SNAPSHOT comment.
    def _capture_ar_connection_classes!
      return if @_ar_conn_classes_captured
      @_ar_conn_classes_captured = true
      return unless defined?(::ActiveRecord::Base) && ::ActiveRecord::Base.respond_to?(:descendants)

      snapshot = {}
      ::ActiveRecord::Base.descendants.each do |klass|
        next unless klass.respond_to?(:connection_class?) && klass.connection_class?
        next if klass.name.nil?
        begin
          db_config = klass.connection_db_config
          next unless db_config
          hash = db_config.configuration_hash.reject { |_k, v| v.nil? }
          next if hash.empty?
          snapshot[klass.name.to_s] = {
            config: hash,
            shard: (klass.default_shard || :default)
          }
        rescue StandardError
          nil
        end
      end
      return if snapshot.empty?

      Ractor.make_shareable(snapshot)
      _reassign_shareable_const(:AR_CONNECTION_CLASSES_SNAPSHOT, snapshot)
    end

    def init_worker_ar_connections!
      return if Ractor.main?
      return unless defined?(::ActiveRecord::Base)

      key = :active_record_connection_handler
      # Store the handler in Ractor-local storage (Ractor.current), NOT in
      # the IES-backed RactorRailsShim.storage. IES is per-THREAD (it is a
      # Thread.attr_accessor), so a value set on the init thread is invisible
      # to the other worker threads in the same worker Ractor ->
      # ConnectionNotEstablished ("No connection handler for Ractor X").
      # Ractor.current storage is per-Ractor and shared by every thread of the
      # worker, so connection_handler resolves the same handler for all threads.
      existing = Ractor.current[key]
      return if existing

      # Establish a fresh, per-Ractor connection handler + pool from the
      # captured configurations snapshot. We call ConnectionHandler#establish_connection
      # DIRECTLY (not ActiveRecord::Base.establish_connection, which writes
      # the `@resolved_config` class ivar from the worker -> IsolationError).
      # ConnectionHandler#establish_connection reads ActiveRecord::Base.configurations
      # (now IES-routed by _install_activerecord_configurations_patch) inside
      # resolve_pool_config, so it works from a worker. Best-effort per config.
      snapshot = AR_CONFIGURATIONS_SNAPSHOT
      if snapshot && !snapshot.empty?
        env = ENV["RAILS_ENV"].presence || ENV["RACK_ENV"].presence || "development"
        env_configs = snapshot[env] || snapshot.values.first || {}

        handler = ::ActiveRecord::ConnectionAdapters::ConnectionHandler.new
        # The DEFAULT shard must be the app's primary database. In a
        # multi-database app (database.yml with primary/secondary) iterating
        # every config under :default made the LAST one win — workers then
        # queried the secondary database and raised PG::UndefinedTable for
        # every primary table. Pick the config named "primary" (Rails'
        # convention) and fall back to the first entry for single-db apps.
        default_config = env_configs["primary"] || env_configs.values.first
        if default_config
          begin
            handler.establish_connection(default_config,
              owner_name: ::ActiveRecord::Base,
              role: ::ActiveRecord::Base.current_role || :writing,
              shard: ::ActiveRecord::Base.current_shard || :default)
          rescue StandardError
            # Best-effort: if the connection fails, continue with others.
          end
        end

        # connects_to-based models (Solid Cache / Solid Queue / Solid Cable
        # style) register their pools under shard keys EQUAL TO THE DATABASE
        # NAME (connects_to database: :primary → shards { primary: ... }) and
        # carry their own default_shard class_attribute (e.g.
        # SolidCache::Record.default_shard == :primary with config/cache.yml
        # `database: primary`). The default-shard pool above does not cover
        # those lookups — a worker querying such a model raises
        #   ConnectionNotDefined: No database connection defined for
        #   SolidCache::Record with 'primary' shard.
        # Register each named env config under its own name as a shard key too
        # (same db_config, so the lazy pools stay cheap).
        #
        # Each named pool is registered for the writing role AND the reading
        # role: `connects_to database: { writing: :secondary, reading:
        # :secondary }` + `connected_to(role: :reading)` otherwise raises
        # "calling `connected_to` is not allowed when there is no connection
        # defined for that role". Both pools point at the same config, so the
        # extra pools are cheap (connections are opened lazily).
        writing_role = (::ActiveRecord::Base.respond_to?(:writing_role) ? ::ActiveRecord::Base.writing_role : :writing)
        reading_role = (::ActiveRecord::Base.respond_to?(:reading_role) ? ::ActiveRecord::Base.reading_role : :reading)
        env_configs.each do |name, config|
          shard = name.to_sym
          [writing_role, reading_role].uniq.each do |role|
            begin
              handler.establish_connection(config,
                owner_name: ::ActiveRecord::Base,
                role: role,
                shard: shard)
            rescue StandardError
              # Best-effort: if one connection fails, continue with others.
            end
          end
        end

        # Models that call `connects_to` own a pool under their own
        # connection_specification_name. A lazily autoloaded class inside a
        # worker re-resolves `connects_to` and picked the PRIMARY config
        # (observed: AuditEntry read the primary database -> PG::UndefinedTable
        # for its own table). Re-establish those pools from the main-captured
        # snapshot, keyed by the model's spec name, for both roles.
        connection_classes = AR_CONNECTION_CLASSES_SNAPSHOT
        if connection_classes && !connection_classes.empty?
          connection_classes.each do |class_name, entry|
            klass = (Object.const_get(class_name) rescue nil)
            next unless klass.is_a?(::Class)
            config = entry[:config]
            next unless config.is_a?(::Hash)
            [writing_role, reading_role].uniq.each do |role|
              begin
                handler.establish_connection(config,
                  owner_name: klass,
                  role: role,
                  shard: (entry[:shard] || :default))
              rescue StandardError
                # Best-effort: continue with the other pools.
              end
            end
          end
        end

        Ractor.current[key] = handler
      end
    end

    # Blockers 3: ActiveRecord model classes cache relation-delegate classes
    # in the `@relation_delegate_cache` class instance variable (set in
    # `DelegateCache#initialize_relation_delegate_cache`,
    # activerecord/relation/delegation.rb:31-44). The cache is a plain (mutable)
    # Hash mapping each delegated class (ActiveRecord::Relation, etc.) to an
    # anonymous delegate Class. From a worker Ractor, reading the class ivar
    # raises Ractor::IsolationError ("can not get unshareable values from
    # instance variables of classes/modules from non-main Ractors
    # (@relation_delegate_cache from Post)") — even a plain `Post.page(1)`.
    #
    # The delegate Classes themselves ARE shareable (verified:
    # Ractor.shareable?(Post::ActiveRecord_Relation) == true). Only the
    # enclosing Hash is mutable (unshareable). So we deep-freeze the cache
    # (Ractor.make_shareable) in the main Ractor at prepare/make-shareable
    # time. A class ivar whose value is shareable is readable from a worker
    # Ractor (unlike class variables, which always raise). Freezing is safe:
    # the cache is populated once per class at load time and never mutated
    # afterwards (each relation-delegate Class is const_set as a private
    # constant on the model class).
    def _install_activerecord_relation_delegate_cache_patch
      return if @ar_rdc_patched
      @ar_rdc_patched = true
      _register_patch :activerecord_relation_delegate_cache, "8.1"
      return unless defined?(::ActiveRecord::Base)

      mod = ::ActiveRecord::Delegation::DelegateCache
      mod.module_eval do
        # The default implementation reads the delegate class from the
        # `@relation_delegate_cache` *class instance variable* — an unshareable
        # Hash populated lazily on the model class. From a worker Ractor that
        # value is unreadable (Ractor::IsolationError: "can not get unshareable
        # values from instance variables ... (@relation_delegate_cache from
        # Post)"). `initialize_relation_delegate_cache` ALSO const_sets each
        # delegate class onto the model (e.g. `Post::ActiveRecord_Relation`),
        # and that constant is shareable. So read the delegate class via the
        # constant instead of the class ivar — Ractor-safe with no per-worker
        # rebuild.
        def relation_delegate_class(klass)
          const_get(klass.name.gsub("::", "_"))
        end

        # Keep building + const_setting the delegate classes (shareable), but
        # stop stashing them in the unshareable `@relation_delegate_cache` ivar.
        # The ivar is left a frozen empty Hash so any (now-unused) reader of it
        # is still Ractor-safe.
        def initialize_relation_delegate_cache
          @relation_delegate_cache = {}.freeze
          ::ActiveRecord::Delegation.delegated_classes.each do |k|
            delegate = Class.new(k) { include ::ActiveRecord::Delegation::ClassSpecificRelation }
            include_relation_methods(delegate)
            mangled_name = k.name.gsub("::", "_")
            const_set mangled_name, delegate
            private_constant mangled_name
          end
        end
      end

      _share_relation_delegate_caches! if Ractor.main?
    end

    # ActiveModel::AttributeMethods::ClassMethods#attribute_method_patterns_cache
    # stores a mutable Concurrent::Map in a CLASS instance variable
    # (@attribute_method_patterns_cache). That ivar is unshareable, so reading
    # it from a worker Ractor raises Ractor::IsolationError ("can not get
    # unshareable values from instance variables of classes/modules from
    # non-main Ractors") — hit on the write path via redirect_to @post ->
    # respond_to? -> matched_attribute_method -> attribute_method_patterns_cache.
    #
    # Unlike @relation_delegate_cache (populated once, freezable), this map is
    # mutated lazily per method_name (compute_if_absent) during request handling,
    # so it cannot be frozen. Instead route it through Ractor-local storage:
    # each Ractor gets its own Concurrent::Map, shared by all of its threads.
    # The cache content is deterministic (a pure function of the class's
    # attribute_method_patterns), so per-Ractor recomputation is correct.
    def _install_active_model_attribute_method_patterns_patch
      return if @am_amp_patched
      @am_amp_patched = true
      _register_patch :active_model_attribute_method_patterns, "8.1"
      return unless defined?(::ActiveModel::AttributeMethods)

      mod = ::ActiveModel::AttributeMethods::ClassMethods
      mod.module_eval do
        def attribute_method_patterns_cache
          store = Ractor.current[:__am_attribute_method_patterns_cache__] ||= {}
          store[object_id] ||= Concurrent::Map.new(initial_capacity: 4)
        end
      end
    end

    # Make every loaded AR model class's @relation_delegate_cache shareable.
    # Idempotent; must run in the main Ractor after eager_load so that all
    # model classes (and their caches) exist.
    def _share_relation_delegate_caches!
      return unless defined?(::ActiveRecord::Base)
      classes = [::ActiveRecord::Base]
      classes.concat(::ActiveRecord::Base.descendants) rescue nil
      classes.each do |klass|
        cache = klass.instance_variable_get(:@relation_delegate_cache) rescue nil
        next unless cache
        next if Ractor.shareable?(cache)
        begin
          klass.instance_variable_set(:@relation_delegate_cache,
            Ractor.make_shareable(cache))
        rescue StandardError => e
          # Best-effort: if a cache holds an unshareable delegate class we
          # can't freeze, skip it. The worker will then hit a clear error on
          # the first relation method and we can patch that class specifically.
        end
      end
    end

    # ActiveRecord model classes lazily initialize many class instance
    # variables on first use (e.g. @table_name, @arel_table, @predicate_builder,
    # @columns_hash, @attribute_methods_module) via `@ivar ||= compute`. The
    # computation is deterministic, but it WRITES the class ivar — which a
    # worker Ractor cannot do (Ractor::IsolationError: "can not set instance
    # variables of classes/modules by non-main Ractors").
    #
    # Fix: in the main Ractor, warm every model class by running representative
    # queries (count / first / page), which populates all the lazy class ivars
    # with their shareable-or-not values. Then make every class ivar's VALUE
    # shareable (deep-freeze via Ractor.make_shareable) and write it back while
    # the class is still mutable in main. A class ivar holding a shareable value
    # is readable from a worker Ractor, and the worker's `||=` short-circuits
    # (no write). Idempotent; must run in the main Ractor after eager_load.
    def _share_model_classes!
      return unless defined?(::ActiveRecord::Base)

      # Suppress reload_schema_from_cache for the rest of the main Ractor's
      # lifecycle. During warming, abstract classes (ActiveRecord::Base,
      # ApplicationRecord) trigger reload_schema_from_cache which recursively
      # resets @schema_loaded = false and @columns_hash = nil on all
      # descendants, destroying schema data that workers need. After
      # make_app_shareable! freezes the graph, no more reloads should happen
      # in main anyway.
      RactorRailsShim.instance_variable_set(:@_rrs_schema_warming, true)

      # Force load_schema on all concrete models BEFORE freezing any
      # reflections. load_schema! writes to reflection objects (e.g.
      # CounterCache writes @counter_cache_column), so it must run before
      # _share_model_classes! freezes them via Ractor.make_shareable.
      classes = [::ActiveRecord::Base]
      classes.concat(::ActiveRecord::Base.descendants) rescue nil
      classes.each do |klass|
        next if klass.respond_to?(:abstract_class?) && klass.abstract_class?
        begin
          klass.send(:load_schema) if klass.respond_to?(:load_schema, true)
        rescue StandardError
          nil
        end
      end

      classes = [::ActiveRecord::Base]
      classes.concat(::ActiveRecord::Base.descendants) rescue nil
      # The per-klass table was frozen at the end of the previous pass (see
      # the worker-shareability freeze at the bottom of this method); dup it
      # back into mutability so this pass can add newly-loaded models.
      @rrs_assoc_scope_attrs = @rrs_assoc_scope_attrs ? @rrs_assoc_scope_attrs.transform_values(&:dup) : {}
      classes.each do |klass|
        # Bake each scoped association's where-values NOW, before the ivar
        # shareability pass below runs `replace_unshareable_procs!` over
        # `@__reflections` — after that, the scope Proc is a NoOpProc, so the
        # scope's attributes would be lost forever. Workers cannot call the
        # scope lambda (its `self` is the not-yet-shareable model class), and
        # AR normally applies the scope's where-values to records built
        # through the association. Observed without this: worker-built
        # ActionText::RichText rows INSERTed with a NULL `name` (the
        # `-> { where(name: name) }` scope on Post#rich_text_content) and hit
        # a NotNullViolation. The frozen table is read by the redefined
        # Association#initialize_attributes (see
        # _install_ar_association_scope_attrs_patch) to re-apply the scope's
        # attributes to records built in workers.
        if klass.name && !(klass.respond_to?(:abstract_class?) && klass.abstract_class?)
          begin
            per = (@rrs_assoc_scope_attrs[klass.name.to_s.freeze] ||= {})
            (klass.reflect_on_all_associations rescue []).each do |refl|
              next if per.key?(refl.name.to_s)
              next unless refl.respond_to?(:scope) && (refl.collection? || refl.has_one?)
              scope = (refl.scope rescue nil)
              next unless scope.is_a?(::Proc) && !scope.class.name.to_s.end_with?("NoOpProc")
              begin
                rel = (klass.unscoped.instance_exec(klass.new, &scope) rescue nil)
                next unless rel.respond_to?(:where_clause)
                wh = {}
                (rel.where_clause.to_h rescue nil)&.each do |col, val|
                  next unless val.nil? || val == true || val == false ||
                              val.is_a?(::Numeric) || val.is_a?(::Symbol) || val.is_a?(::String)
                  wh[col.to_s.freeze] = val.is_a?(::String) ? val.freeze : val
                end
                per[refl.name.to_s.freeze] = wh.freeze unless wh.empty?
              rescue StandardError
                nil
              end
            end
          rescue StandardError
            nil
          end
        end

        # Warm the class's lazy ivars by actually exercising the query paths
        # the workers will hit. Main has a working connection handler, so this
        # populates exactly the ivars a real query touches. Each call is
        # isolated: a failure in one must not skip the rest (e.g. the private
        # `relation` method or a cold connection must not prevent `table_name`
        # from being set).
        warm_calls = [
          -> { klass.connection_pool if klass.respond_to?(:connection_pool) },
          -> { klass.send(:reset_primary_key) if klass.respond_to?(:reset_primary_key, true) },
          -> { klass.table_name },
          -> { klass.arel_table },
          -> { klass.columns_hash },
          -> { klass.attribute_names },
          -> { klass.attribute_types },
          -> { klass.predicate_builder },
          -> { klass.defined_enums if klass.respond_to?(:defined_enums) },
          -> { klass.send(:relation) if klass.respond_to?(:relation, true) },
          -> { klass.count rescue nil },
          -> { klass.first rescue nil },
          -> { klass.send(:query_constraints_list) if klass.respond_to?(:query_constraints_list, true) },
          -> { if defined?(::Kaminari) && klass.respond_to?(:page)
                 klass.page(1).to_a rescue nil
               end },
        ]
        warm_calls.each { |c| begin; c.call; rescue StandardError => e; end }

        # Warm reflection objects. Reflections are part of the model class
        # graph and get deep-frozen by make_app_shareable!. Their lazy caches
        # (@class_name, @klass, @inverse_name, @scope, etc.) memoize via ||=
        # which writes to a frozen object from a worker -> FrozenError. Warm
        # them here in main so the frozen copies hold the values.
        begin
          if klass.respond_to?(:reflect_on_all_associations, true)
            klass.reflect_on_all_associations.each do |refl|
              begin
                refl.class_name rescue nil
                refl.klass rescue nil
                refl.inverse_name rescue nil
                refl.inverse_of rescue nil
                refl.active_record rescue nil
                refl.plural_name rescue nil
                refl.options rescue nil
                refl.macro rescue nil
                refl.scope rescue nil if refl.respond_to?(:scope)
                refl.check_validity! rescue nil
                refl.automatic_inverse_of rescue nil if refl.respond_to?(:automatic_inverse_of)
              rescue StandardError
                nil
              end
            end
          end
        rescue StandardError
          nil
        end

        # Make every class ivar shareable and write it back. The class is
        # still mutable here (in main), so the write is allowed.
        begin
          klass.instance_variables.each do |iv|
            v = klass.instance_variable_get(iv) rescue nil
            next unless v
            next if Ractor.shareable?(v)
            replacement = _shareable_ivar_replacement(v)
            next unless replacement
            begin
              klass.instance_variable_set(iv, replacement)
            rescue StandardError => e
              # frozen owner — leave as-is
            end
          end
        rescue StandardError => e
          # BasicObject / frozen owners
        end

      end

      # Freeze the baked association-scope table for worker readability: a
      # module ivar is only readable from a worker Ractor when its value is
      # shareable. Called once per _share_model_classes! pass; later passes
      # dup the per-klass hashes back into mutability at the top of the
      # per-class walk.
      if @rrs_assoc_scope_attrs
        @rrs_assoc_scope_attrs.each_value(&:freeze)
        @rrs_assoc_scope_attrs.freeze
      end

      # Build the per-model shareable snapshots (primary keys + pending
      # attribute modifications) workers read instead of un-shareable class
      # ivars. Delegated to _rebuild_activerecord_model_snapshots! so it can
      # be called again post-eager-load (at make_app_shareable! time) once
      # ActiveRecord::Base.descendants holds the app's models.
      _capture_dependent_associations!
      _rebuild_activerecord_model_snapshots!
    end

    # Capture every AR model's `dependent:` associations into the shareable
    # SHAREABLE_DEPENDENT_ASSOCIATIONS table so worker Ractors can replay them
    # (see StorageStrategy::Ractor#replay_callbacks! / the :destroy branch of
    # the nil-safe run_callbacks patch). The `dependent:` lambda filter is an
    # unshareable Proc, so it can't live in the frozen, shared __callbacks
    # chain; instead we record (model_name => [{name:, type:, macro:}]) and
    # re-drive `record.association(name).handle_dependency` in workers. Runs in
    # the main Ractor after eager-load (reflections + descendants are ready).
    def _capture_dependent_associations!
      return unless defined?(::ActiveRecord::Base)
      table = {}
      classes = [::ActiveRecord::Base]
      classes.concat(::ActiveRecord::Base.descendants) rescue nil
      classes.each do |klass|
        name = klass.name
        next unless name
        next if klass.respond_to?(:abstract_class?) && klass.abstract_class?
        begin
          next unless klass.respond_to?(:reflect_on_all_associations, true)
          klass.reflect_on_all_associations.each do |refl|
            dep = refl.options[:dependent]
            next unless dep
            (table[name] ||= []) << {
              name: refl.name.to_sym,
              type: dep.to_sym,
              macro: refl.macro,
            }
          end
        rescue StandardError => e
          warn "ractor-rails-shim: dependent-association capture failed for #{name} (#{e.class}: #{e.message[0, 140]})"
          nil
        end
      end
      _reassign_shareable_const(
        :SHAREABLE_DEPENDENT_ASSOCIATIONS,
        Ractor.make_shareable(table)
      )
    end

    # (Re)build the per-model shareable snapshots that workers read instead of
    # un-shareable class ivars: AR_PRIMARY_KEYS_SHAREABLE (model name -> primary
    # key) and SHAREABLE_PENDING_ATTR_MODS (model object_id -> attribute macro
    # modifications). Separated from _share_model_classes! so it can be called
    # again AFTER eager-load (at make_app_shareable! time), when
    # ActiveRecord::Base.descendants actually contains the app's models. Called
    # too early (e.g. during the initial install, before eager-load) it only
    # captures ActiveRecord::Base — the post-boot call overwrites the constant
    # with the complete map, which is what workers spawned after
    # make_app_shareable! read.
    def _rebuild_activerecord_model_snapshots!
      return unless defined?(::ActiveRecord::Base)

      classes = [::ActiveRecord::Base]
      classes.concat(::ActiveRecord::Base.descendants) rescue nil

      # The pending-mod lists must be shareable BEFORE this capture: the
      # enum/attribute-macro decoration Procs inside the pending Structs are
      # invisible to the ivar-walk Proc replacement (Struct members are not
      # ivars) and Ruby refuses make_shareable on the enum decoration closure
      # ("outer variable 'validate' may be reassigned" in
      # ActiveRecord::Enum#enum). _share_ar_pending_attribute_modifications!
      # rebuilds the lists as shareable Structs first; without it the
      # make_shareable below raised IsolationError and the model was dropped
      # from the capture — workers fell back to [] and lost the attribute
      # type registration (observed: `p.state` cast to raw 0 and
      # `state = :moderated` to nil in workers for enum columns).
      _share_ar_pending_attribute_modifications! if Ractor.main?

      # pending attribute modifications (custom attribute macros)
      capture = {}
      classes.each do |klass|
        n = klass.name
        next unless n
        begin
          mods = klass.instance_variable_get(:@pending_attribute_modifications)
          if mods && mods.is_a?(Array) && !mods.empty?
            shareable = mods.dup
            Ractor.make_shareable(shareable)
            capture[klass.object_id] = shareable
          end
        rescue StandardError
          nil
        end
      end
      capture.freeze
      Ractor.make_shareable(capture)
      RactorRailsShim._reassign_shareable_const(:SHAREABLE_PENDING_ATTR_MODS, capture)

      # primary keys
      pk_map = {}
      classes.each do |klass|
        n = klass.name
        next unless n
        pk = klass.primary_key rescue next
        pk_map[n] = pk if pk
      end
      shareable = Ractor.make_shareable(pk_map)
      _reassign_shareable_const(:AR_PRIMARY_KEYS_SHAREABLE, shareable)
    end

    # Pre-warm lazy CLASS-IVAR memoizations on every AR descendant in the MAIN
    # Ractor so workers only ever READ them (post-freeze a worker write raises
    # IsolationError):
    # - connection_class: `@connection_class ||= false` (core.rb) re-ASSIGNS
    #   whenever the stored value is false (falsy), so a pre-warmed `false`
    #   alone is not enough — connection_class is re-defined (string eval) to
    #   write only when the ivar is UNDEFINED, and the ivar is pre-defined on
    #   Base + all descendants here. Read on every query via
    #   current_role -> connection_class? (SolidCache's
    #   Entry.without_query_cache walks it per model class too).
    # - @_type_candidates_cache: compute_type's memoized type-name map
    #   (inheritance.rb) — written on the first reflection klass computation
    #   (AssociationReflection#compute_class). The cache is PER OWNER CLASS
    #   and keyed by the REFERENCED class name, so every (owner, name) pair
    #   is pre-warmed (N^2 over models — bounded, tens of calls). Once a
    #   frozen instance exists (built in main during boot), a worker adding a
    #   missing entry raises FrozenError ("can't modify frozen Hash").
    # Rails::Engine#isolate_namespace installs Proc-backed singleton methods on
    # the engine's NAMESPACE module (SolidCable, ActionText, SolidQueue, ...):
    #
    #   define_method(:railtie_namespace) { railtie }                  # captures the engine class
    #   define_method(:table_name_prefix) { "#{name}_" }               # + an on_load redefine variant
    #
    # define_method bodies are Procs. A worker calling them raises
    # "defined with an un-shareable Proc in a different Ractor" — observed for
    # lazily-loaded engine models (SolidCable::Message via /cable_probe):
    # table_name -> compute_table_name -> full_table_name_prefix ->
    # SolidCable.table_name_prefix -> Proc from main -> RuntimeError, and the
    # model's table name then computes WRONG ("messages" instead of
    # "solid_cable_messages"). Engine-namespaced models are therefore unusable
    # from a worker unless they were loaded (and prewarmed) in main before
    # spawn.
    #
    # Fix: re-define both singletons as REAL def methods (no Proc) with the
    # engine name baked in as a literal. Only the Engine-defined methods are
    # replaced (detected via source_location) — an app's explicit
    # table_name_prefix definition wins, exactly as `isolate_namespace`
    # respects it with its `unless mod.respond_to?` guard. Idempotent.
    def _redefine_engine_railtie_singletons!
      return unless defined?(::Rails::Engine)
      return unless Ractor.main?

      ::Rails::Engine.subclasses.each do |engine_class|
        next unless engine_class.isolated?
        mod = (engine_class.railtie_namespace rescue nil) || engine_class.module_parent
        next unless mod.is_a?(Module)
        sc = mod.singleton_class

        # table_name_prefix — only the Engine definition (railties engine.rb).
        if sc.method_defined?(:table_name_prefix) || sc.private_method_defined?(:table_name_prefix)
          src = (sc.instance_method(:table_name_prefix).source_location rescue nil)
          # Ruby 4 source_location returns an Array of locations.
          srcs = src.is_a?(Array) ? src : [src]
          if srcs.any? { |s| s.is_a?(String) && s.end_with?("lib/rails/engine.rb") }
            prefix = "#{mod.name.underscore}_"
            sc.class_eval <<~RUBY, __FILE__, __LINE__ + 1
              remove_method :table_name_prefix
              def table_name_prefix
                base = ::ActiveRecord::Base.table_name_prefix rescue ""
                base + "#{prefix}"
              end
            RUBY
          end
        end

        # railtie_namespace — same Proc problem, same source.
        if sc.method_defined?(:railtie_namespace)
          src = (sc.instance_method(:railtie_namespace).source_location rescue nil)
          srcs = src.is_a?(Array) ? src : [src]
          if srcs.any? { |s| s.is_a?(String) && s.end_with?("lib/rails/engine.rb") }
            engine_class_name = engine_class.name
            sc.class_eval <<~RUBY, __FILE__, __LINE__ + 1
              remove_method :railtie_namespace
              def railtie_namespace
                ::#{engine_class_name}
              end
            RUBY
          end
        end
      end
    rescue StandardError => e
      # Best-effort: without the redefinition, engine-namespaced models that
      # were NOT prewarmed in main still fail in workers (as before).
      warn "ractor-rails-shim: engine railtie singleton redefinition failed " \
           "(#{e.class}: #{e.message[0, 200]})"
      nil
    end

    def _prewarm_activerecord_memoizations!
      return unless defined?(::ActiveRecord::Base)

      _redefine_engine_railtie_singletons!
      _redefine_ar_autosave_methods!
      _redefine_ar_enum_methods!
      _share_activemodel_validation_constants!
      _share_ar_pending_attribute_modifications!

      unless @ar_memoization_patches_installed
        @ar_memoization_patches_installed = true

        # connection_class: `@connection_class ||= false` re-ASSIGNS whenever
        # the stored value is false (falsy) — on a frozen class in a worker
        # that is an IsolationError even though the read is harmless. Write
        # only when the ivar is UNDEFINED instead.
        base_singleton = class << ::ActiveRecord::Base; self; end
        base_singleton.class_eval <<~RUBY, __FILE__, __LINE__ + 1
          remove_method :connection_class
          def connection_class
            if instance_variable_defined?(:@connection_class)
              @connection_class
            else
              @connection_class = false
            end
          end
        RUBY

        # compute_type: a worker computing a type whose entry is missing from
        # the FROZEN @_type_candidates_cache raises FrozenError on the memo
        # write ("can't modify frozen Hash") — e.g. the first reflection klass
        # computation for a new association during a destroy cascade. Workers
        # (frozen classes) resolve through safe_constantize every time without
        # memoizing; main keeps upstream semantics.
        inheritance_mod = ::ActiveRecord::Inheritance::ClassMethods
        inheritance_mod.class_eval <<~RUBY, __FILE__, __LINE__ + 1
          remove_method :compute_type
          protected def compute_type(type_name)
            if type_name.start_with?("::")
              type_name.constantize
            else
              type_candidate = @_type_candidates_cache[type_name]
              if type_candidate && (type_constant = type_candidate.safe_constantize)
                return type_constant
              end

              candidates = []
              name.scan(/::|$/) { candidates.unshift "\#{$`}::\#{type_name}" }
              candidates << type_name

              candidates.each do |candidate|
                constant = candidate.safe_constantize
                if candidate == constant.to_s
                  # Memoize only when the cache can accept writes. Worker
                  # model classes are UNFROZEN clones that share the frozen
                  # cache Hash built in main — `frozen?` on the class is not
                  # the right guard, the cache's own frozen state is.
                  @_type_candidates_cache[type_name] = candidate unless @_type_candidates_cache.frozen?
                  return constant
                end
              end

              raise NameError.new("uninitialized constant \#{candidates.first}", candidates.first)
            end
          end
        RUBY
      end

      classes = [::ActiveRecord::Base]
      classes.concat(::ActiveRecord::Base.descendants) rescue nil
      classes = classes.select { |klass| klass.name }

      # connection_class ivar defined (not just false-assigned) in main.
      classes.each do |klass|
        begin
          klass.connection_class
        rescue StandardError
          nil
        end
      end

      # Complete the per-owner type caches in main (N^2 over models — bounded,
      # tens of pairs) so workers hit the frozen cache for every reflection.
      # send() bypasses the `protected` visibility check (an explicit-receiver
      # protected call from this module context would raise NoMethodError).
      classes.each do |owner|
        classes.each do |referenced|
          begin
            owner.send(:compute_type, referenced.name) if owner.respond_to?(:compute_type, true)
          rescue StandardError, NameError
            nil
          end
        end
      end
    end
    #  - Monitor/Mutex  -> NoOpLock (never contended post-boot)
    #  - Concurrent::Map -> frozen Hash
    #  - else           -> Ractor.make_shareable; if that fails (statement
    #                      caches etc.), a frozen empty container of the same
    #                      kind so the worker reads a shareable value (cold
    #                      cache in workers; slower, correct). Returns nil if
    #                      no replacement can be made.
    def _shareable_ivar_replacement(v)
      if v.is_a?(::Monitor) || v.is_a?(::Mutex)
        Ractor.make_shareable(NoOpLock.new)
      elsif defined?(::Concurrent::Map) && v.is_a?(::Concurrent::Map)
        h = {}
        begin
          v.each_pair { |k, val| h[k] = val }
        rescue StandardError => e
        end
        Ractor.make_shareable(h)
      else
        # Replace unshareable Procs BEFORE make_shareable. A failed
        # make_shareable can partially freeze the graph it traversed, which
        # would make a later in-place Proc replacement impossible (writing a
        # frozen object's ivar raises). The traversal uses the same
        # PROC_REPLACEMENTS table as the global app pass, and the specific
        # builders there target Rack/Devise/routes Procs that never live
        # under model-class ivars — so early replacement here is equivalent.
        # Idempotent no-op walk for graphs without Procs.
        begin
          ::RactorRailsShim::ShareabilityTraversal.replace_unshareable_procs!(v)
        rescue StandardError
          nil
        end
        begin
          Ractor.make_shareable(v)
        rescue StandardError => e
          # NEVER substitute an empty twin ({} / [] / Set.new) for a container
          # whose contents are unshareable. The twin would be WRITTEN BACK
          # onto the class, silently destroying memoized data (observed:
          # Post's @__reflections memoized a Hash of Reflection objects — the
          # {} swap made reflect_on_all_associations return [] forever, which
          # broke dependent-association capture and autosave redefinition for
          # Post). Leaving the original value is safe: a worker reading a
          # still-unshareable value gets a LOUD IsolationError instead of
          # silently-empty results.
          nil
        end
      end
    end

    # ActiveRecord's internal helper classes (the *Clause classes used while
    # building a relation's Arel) cache a frozen "empty" singleton in a class
    # instance variable via `@empty ||= new(...).freeze` (e.g.
    # ActiveRecord::Relation::WhereClause#empty). Reading that class ivar from
    # a worker Ractor raises Ractor::IsolationError if the value isn't
    # shareable. Fix: warm `.empty` in the main Ractor (populating @empty with
    # its frozen singleton), then make every class ivar on these helper
    # classes shareable. Idempotent; must run in the main Ractor.
    # ActiveRecord's internal helper classes/modules hold class instance
    # variables that a worker Ractor reads during query building / connection
    # establishment (e.g. `ActiveRecord::ConnectionAdapters.@adapters` — a Hash
    # of adapter_name => [class_name, path]; the `*Clause` classes' `@empty`
    # frozen singleton). A class ivar whose VALUE is shareable IS readable from
    # a worker Ractor (unlike class variables), so we deep-freeze each value
    # in the main Ractor and write it back (Monitor/Mutex->NoOpLock,
    # Concurrent::Map->frozen Hash, etc. via _shareable_ivar_replacement).
    #
    # TARGETED: only specific leaf registries (not a broad ActiveRecord::*
    # sweep). A broad sweep also freezes AR-railtie initializer Collections
    # reachable from the app graph, which breaks make_app_shareable's
    # proc-replacement (frozen containers can't be mutated to swap Procs).
    def _share_active_record_internals!
      return unless defined?(::ActiveRecord::Base)

      # 1. Warm + freeze the *Clause `.empty` singletons.
      ObjectSpace.each_object(Class) do |c|
        n = c.name
        next unless n && n.start_with?("ActiveRecord::Relation::") &&
                    n.end_with?("Clause")
        begin
          c.empty if c.respond_to?(:empty)
        rescue StandardError => e
        end
        _freeze_class_ivars!(c)
      end

      # 2. ConnectionAdapters.@adapters (String => [class_name, path]) — read
      #    by `ConnectionAdapters.resolve` during establish_connection.
      if defined?(::ActiveRecord::ConnectionAdapters)
        _freeze_class_ivars!(::ActiveRecord::ConnectionAdapters)
      end

      # 3. ActiveRecord::Type — holds @default_value (a lazy singleton Value
      #    used as a fallback type). Warm it and freeze the class ivar.
      if defined?(::ActiveRecord::Type)
        ::ActiveRecord::Type.default_value rescue nil
        _freeze_class_ivars!(::ActiveRecord::Type)
      end

      # 4. ActiveModel::Type — holds @default_value and @registry (contains
      #    Procs). Can't freeze the class ivars (Registry has Procs). Route
      #    default_value through IsolatedExecutionState so worker Ractors get
      #    their own lazily-initialized copy.
      if defined?(::ActiveModel::Type)
        _patch_active_model_type_default_value!
      end

      # 5. ActiveRecord::Associations::AssociationScope::INSTANCE is an instance
      #    singleton wrapping an unshareable identity lambda. Worker Ractors
      #    read it on EVERY association scope build (AssociationScope.scope),
      #    so it must be Ractor-shareable. Replace the constant with a
      #    deep-frozen, shareable copy built in the main Ractor — the same
      #    pattern as _freeze_journey_visitors! for Journey's *::INSTANCE.
      if defined?(::ActiveRecord::Associations::AssociationScope) &&
         ::ActiveRecord::Associations::AssociationScope.const_defined?(:INSTANCE)
        inst = ::ActiveRecord::Associations::AssociationScope::INSTANCE
          unless Ractor.shareable?(inst)
            _swallow("make AssociationScope::INSTANCE shareable") do
              # Reassigning a constant that already exists warns ("already
              # initialized constant"); drop the old binding first.
              ::ActiveRecord::Associations::AssociationScope.send(:remove_const, :INSTANCE) if ::ActiveRecord::Associations::AssociationScope.const_defined?(:INSTANCE, false)
              ::ActiveRecord::Associations::AssociationScope.const_set(
                :INSTANCE, Ractor.make_shareable(inst)
              )
            end
        end
      end
    end

    def _patch_active_model_type_default_value!
      return if @active_model_type_default_patched
      @active_model_type_default_patched = true
      _register_patch :active_model_type_default_value, "8.1"
      return unless defined?(::ActiveModel::Type::Value)
      return unless ::ActiveModel::Type.respond_to?(:default_value)

      # Warm the default in the main Ractor and build a shareable copy that
      # workers can read. Workers MUST NOT call _rrs_orig_default_value because
      # the original reads @default_value (a class ivar on ActiveModel::Type)
      # which is not accessible from non-main Ractors. Capture + shareable-copy
      # the template HERE (in main, at patch time) so the worker's patched
      # method never touches the raw ivar.
      main_default = ::ActiveModel::Type.default_value rescue nil
      return unless main_default

      # Build a shareable copy of the default_value now (in main) so workers
      # can read it without touching the class ivar.
      shareable_default = begin
        copy = main_default.dup
        Ractor.make_shareable(copy) rescue copy
      end

      ::ActiveModel::Type.singleton_class.class_eval do
        alias_method :_rrs_orig_default_value, :default_value
        def default_value
          if Ractor.main?
            _rrs_orig_default_value
          else
            RactorRailsShim.storage[:rrs_am_type_default_value] ||= (
              RactorRailsShim::SHAREABLE_AM_TYPE_DEFAULT
            )
          end
        end
      end

      # Store the shareable default as a constant so workers can read it
      # without touching @default_value on ActiveModel::Type.
      _reassign_shareable_const(:SHAREABLE_AM_TYPE_DEFAULT, shareable_default)
    end

    # Make every unshareable class ivar on `owner` shareable (deep-freeze) and
    # write it back. A class ivar holding a shareable value is readable from a
    # worker Ractor. Monitor/Mutex->NoOpLock; Concurrent::Map->frozen Hash;
    # values that can't be frozen (Procs, TypeMap) are left as-is.
    def _freeze_class_ivars!(owner)
      begin
        owner.instance_variables.each do |iv|
          v = owner.instance_variable_get(iv) rescue nil
          next unless v
          next if Ractor.shareable?(v)
          replacement = _shareable_ivar_replacement(v)
          next unless replacement
          begin
            owner.instance_variable_set(iv, replacement)
          rescue StandardError => e
            # frozen owner — leave as-is
          end
        end
      rescue StandardError => e
      end
    end

    # Register + run the model-class shareability patch (Blocker: AR model
    # class lazy class-ivar initialization from workers).
    def _install_activerecord_model_classes_patch
      return if @ar_model_classes_patched
      @ar_model_classes_patched = true
      _register_patch :activerecord_model_classes, "8.1"
      return unless defined?(::ActiveRecord::Base)
      _share_model_classes! if Ractor.main?
      _share_active_record_internals! if Ractor.main?
    end

    # Patch ActiveRecord::AttributeMethods::ClassMethods#define_attribute_methods
    # to no-op in worker Ractors. The method writes @attribute_methods_generated
    # (a class ivar) and calls load_schema + super(attribute_names) which
    # generate methods on the class. In a worker, all of these either write
    # class ivars (IsolationError) or try to define methods on a frozen class
    # (FrozenError). The attribute methods were already generated in main by
    # generate_ar_attribute_methods!, so workers just need to skip this.
    def _install_activerecord_define_attribute_methods_patch
      return if @ar_define_attr_methods_patched
      @ar_define_attr_methods_patched = true
      _register_patch :activerecord_define_attribute_methods, "8.1"
      return unless defined?(::ActiveRecord::AttributeMethods::ClassMethods)

      ::ActiveRecord::AttributeMethods::ClassMethods.module_eval do
        alias_method :_rrs_orig_define_attribute_methods, :define_attribute_methods
        def define_attribute_methods
          if Ractor.main?
            _rrs_orig_define_attribute_methods
          else
            # Worker: attribute methods were generated in main. Return true
            # (the original returns true on success) without writing class ivars.
            true
          end
        end
      end
    end

    # Patch ActiveRecord::ModelSchema::ClassMethods so worker Ractors do not
    # write the `@table_name` (and related) class ivars on the shared model
    # class. `table_name` memoizes via `reset_table_name unless
    # defined?(@table_name)`, and `reset_table_name` calls `self.table_name =`
    # which writes `@table_name`/`@arel_table`/etc. From a worker that write is
    # Ractor::IsolationError. Route the value through IsolatedExecutionState
    # (keyed by model object_id); main keeps the original class-ivar behavior.
    #
    # NOTE on naming: there are TWO ModelSchema-related install methods, with
    # deliberately different scopes:
    #   * `_install_active_record_model_schema_patch`  (this method) — patches
    #     `table_name` / `table_name=` / `reset_table_name` only.
    #   * `_install_activerecord_model_schema_patch`  (below) — patches the
    #     *column-derived* lazy caches `symbol_column_to_string`,
    #     `content_columns` (and previously `column_defaults`, now provided
    #     by the prepended `ActiveRecordModelSchemaPatch`).
    # Both target `ActiveRecord::ModelSchema::ClassMethods` but patch
    # disjoint method sets; do not collapse them without auditing every
    # caller.
    def _install_active_record_model_schema_patch
      return if @ar_model_schema_patched
      @ar_model_schema_patched = true
      _register_patch :active_record_model_schema, "8.1"
      return unless defined?(::ActiveRecord::ModelSchema::ClassMethods)
      mod = ::ActiveRecord::ModelSchema::ClassMethods
      mod.module_eval do
        # `columns_hash` reads `@columns_hash`. The original only loads via
        # `load_schema` when `@columns_hash` is nil. In a worker Ractor, class
        # instance variables are NOT shared with the main Ractor (reading
        # `@columns_hash` set in main raises Ractor::IsolationError, or — under
        # kino's worker Ractors, which do not share main's class-ivar space —
        # returns the worker's own nil view). So `load_schema!` (patched to a
        # no-op in workers) never populates it, and the model's schema is
        # permanently nil in workers. Mirror the worker `table_name` patch
        # (below): cache the loaded schema per-Ractor in IES
        # (ActiveSupport::IsolatedExecutionState, readable from every worker
        # Ractor) instead of the un-shareable class ivar. Main keeps the
        # original class-ivar path (frozen into the shared graph).
        def columns_hash
          if ::Ractor.main? || abstract_class?
            load_schema if @columns_hash.nil?
            @columns_hash
          else
            store = (RactorRailsShim.storage[:rrs_columns_hash] ||= {})
            cached = store[self.object_id]
            return cached if cached

            cols = connection_pool.schema_cache.columns_hash(table_name)
            if cols.nil? || cols.empty?
              # Cache was cold (fresh worker pool). Force a load from the DB
              # via the (lazily established) worker connection.
              begin
                cols = connection.columns(table_name).index_by(&:name)
              rescue StandardError
                cols = nil
              end
            end
            cols = cols.freeze if cols
            store[self.object_id] = cols if cols
            cols
          end
        end

        def table_name
          if Ractor.main?
            reset_table_name unless defined?(@table_name)
            @table_name
          else
            store = (RactorRailsShim.storage[:rrs_table_names] ||= {})
            store.fetch(object_id) { store[object_id] = compute_table_name }
          end
        end

        def table_name=(value)
          value = value && value.to_s
          if Ractor.main?
            if defined?(@table_name)
              return if value == @table_name
              reset_column_information if connected?
            end
            @table_name        = value
            @arel_table        = nil
            @sequence_name     = nil unless @explicit_sequence_name
            @predicate_builder = nil
          else
            (RactorRailsShim.storage[:rrs_table_names] ||= {})[object_id] = value
          end
        end

        # NOTE: module_eval REPLACES the original `reset_table_name` in place
        # (same module), so a plain `super` from this override would skip past
        # ModelSchema::ClassMethods and find nothing — "super: no superclass
        # method 'reset_table_name'" on the first lazy call in main post-patch
        # (observed on HABTM join models, whose table names resolve lazily via
        # the builder's table_name_resolver). Capture the original first and
        # call it explicitly.
        alias_method :__rrs_original_reset_table_name, :reset_table_name

        def reset_table_name
          if Ractor.main?
            __rrs_original_reset_table_name
          else
            table_name
          end
        end

        # `full_table_name_prefix` / `full_table_name_suffix` are reached from
        # `compute_table_name` whenever a model's `table_name` is NOT already
        # cached in the worker (e.g. ActiveStorage::Attachment / Blob, whose
        # explicit `table_name=` is set in main and so is invisible to a
        # worker's per-Ractor IES). Upstream they use
        # `module_parents.detect { |p| p.respond_to?(:table_name_prefix) }` —
        # the literal block is compiled in the main Ractor and is un-shareable,
        # so invoking it from a worker raises "defined with an un-shareable Proc
        # in a different Ractor". Reimplement with a plain `while` loop (no
        # block) that yields identical results.
        def full_table_name_prefix
          parents = module_parents
          i = 0
          while i < parents.length
            p = parents[i]
            return p.table_name_prefix if p.respond_to?(:table_name_prefix)
            i += 1
          end
          table_name_prefix || ""
        rescue StandardError => e
          # A prefix read can still fail in a worker (an unpatched Proc-backed
          # reader). Returning "" silently produced WRONG table names
          # ("messages" instead of "solid_cable_messages" — observed for
          # lazily-loaded engine models), so surface the cause loudly.
          warn "ractor-rails-shim: full_table_name_prefix failed for #{name} " \
               "(#{e.class}: #{e.message[0, 200]}) — falling back to \"\""
          ""
        end

        def full_table_name_suffix
          parents = module_parents
          i = 0
          while i < parents.length
            p = parents[i]
            return p.table_name_suffix if p.respond_to?(:table_name_suffix)
            i += 1
          end
          table_name_suffix || ""
        rescue StandardError => e
          warn "ractor-rails-shim: full_table_name_suffix failed for #{name} " \
               "(#{e.class}: #{e.message[0, 200]}) — falling back to \"\""
          ""
        end
      end

      # `attribute_names` is defined on `ActiveRecord::AttributeMethods::
      # ClassMethods` (NOT ModelSchema), and that module sits earlier in the
      # ancestor chain, so a ModelSchema-side patch would be shadowed. Its main
      # path memoizes via `attribute_types` (an unshareable class ivar) and
      # `table_exists?` (writes `@table_exists`), both of which raise from a
      # worker Ractor. Patch it directly: main keeps the original via `super`;
      # workers use `columns_hash.keys` (already routed through per-Ractor
      # IES), a faithful substitute for the DB-backed attribute names.
      if defined?(::ActiveRecord::AttributeMethods::ClassMethods)
        am_mod = ::ActiveRecord::AttributeMethods::ClassMethods
        unless am_mod.method_defined?(:_rrs_orig_attribute_names)
          am_mod.alias_method(:_rrs_orig_attribute_names, :attribute_names)
        end
        am_mod.module_eval do
          def attribute_names
            if ::Ractor.main?
              _rrs_orig_attribute_names
            else
              key = :"rrs_attribute_names_#{object_id}"
              RactorRailsShim.storage[key] ||= if abstract_class?
                []
              else
                columns_hash.keys
              end.freeze
            end
          end
        end
      end
    end

    # Patch ActiveRecord::Core::ClassMethods#arel_table / #predicate_builder /
    # #type_caster. Each memoizes an unshareable value (@arel_table is an
    # Arel::Table, @predicate_builder a PredicateBuilder) on the shared model
    # class. From a worker Ractor the `||=` write raises Ractor::IsolationError,
    # and reading the unshareable cached value also raises. Build + cache each
    # per-Ractor via IsolatedExecutionState (keyed by model object_id); main
    # keeps the original class-ivar behavior.
    def _install_active_record_core_patch
      return if @ar_core_patched
      @ar_core_patched = true
      _register_patch :active_record_core, "8.1"
      return unless defined?(::ActiveRecord::Core::ClassMethods)
      mod = ::ActiveRecord::Core::ClassMethods
      mod.module_eval do
        def arel_table
          if Ractor.main?
            @arel_table ||= ::Arel::Table.new(table_name, klass: self)
          else
            store = (RactorRailsShim.storage[:rrs_arel_tables] ||= {})
            store.fetch(object_id) { store[object_id] = ::Arel::Table.new(table_name, klass: self) }
          end
        end

        def predicate_builder
          if Ractor.main?
            @predicate_builder ||= ::ActiveRecord::PredicateBuilder.new(
              ::ActiveRecord::TableMetadata.new(self, arel_table))
          else
            store = (RactorRailsShim.storage[:rrs_predicate_builders] ||= {})
            store.fetch(object_id) do
              store[object_id] = ::ActiveRecord::PredicateBuilder.new(
                ::ActiveRecord::TableMetadata.new(self, arel_table))
            end
          end
        end

        def type_caster
          if Ractor.main?
            @type_caster ||= ::ActiveRecord::TypeCaster::Map.new(self)
          else
            store = (RactorRailsShim.storage[:rrs_type_casters] ||= {})
            store.fetch(object_id) { store[object_id] = ::ActiveRecord::TypeCaster::Map.new(self) }
          end
        end

        # inspection_filter memoizes @inspection_filter as a class ivar on the
        # (shared, frozen) model class. From a worker Ractor that write raises
        # Ractor::IsolationError ("can not set instance variables of
        # classes/modules by non-main Ractors") — e.g. whenever a model is
        # inspected during a request (backtraces, journey route-formatter
        # Hash#inspect, debug output). Route the memoization through
        # IsolatedExecutionState keyed by the model class instead, preserving
        # the original superclass-delegation semantics.
        def inspection_filter
          store = (RactorRailsShim.storage[:rrs_inspection_filters] ||= {})
          return store[self] if store.key?(self)
          result = if @filter_attributes.nil?
            superclass.inspection_filter
          else
            mask = ::ActiveRecord::Core.const_get(:InspectionMask).new(ActiveSupport::ParameterFilter::FILTERED)
            ActiveSupport::ParameterFilter.new(@filter_attributes, mask: mask)
          end
          store[self] = result
        end
      end
    end

    # Patch ActiveRecord::Inheritance::ClassMethods#finder_needs_type_condition?.
    # It memoizes `@finder_needs_type_condition` (a Symbol) on the shared model
    # class via `@ivar ||=`. From a worker Ractor that write raises
    # Ractor::IsolationError. Route the value through IsolatedExecutionState
    # (keyed by model object_id); main keeps the original class-ivar behavior.
    def _install_active_record_inheritance_patch
      return if @ar_inheritance_patched
      @ar_inheritance_patched = true
      _register_patch :active_record_inheritance, "8.1"
      return unless defined?(::ActiveRecord::Inheritance::ClassMethods)
      mod = ::ActiveRecord::Inheritance::ClassMethods
      mod.module_eval do
        def finder_needs_type_condition?
          if Ractor.main?
            :true == (@finder_needs_type_condition ||= descends_from_active_record? ? :false : :true)
          else
            store = (RactorRailsShim.storage[:rrs_finder_type_cond] ||= {})
            store.fetch(object_id) do
              store[object_id] = descends_from_active_record? ? false : true
            end
          end
        end
      end
    end
    # (an ActiveModel::Name holding unfrozen, unshareable Strings) on the model
    # class. From a worker Ractor that write raises Ractor::IsolationError ("can
    # not set instance variables of classes/modules by non-main Ractors") and
    # reading the unshareable value raises too. Route the cache through
    # IsolatedExecutionState (keyed by model object_id) so each Ractor builds
    # and keeps its own ActiveModel::Name without touching the shared class
    # ivar.
    def _install_active_model_naming_patch
      return if @am_naming_patched
      @am_naming_patched = true
      _register_patch :active_model_naming, "8.1"
      return unless defined?(::ActiveModel::Naming)
      mod = ::ActiveModel::Naming
      mod.module_eval do
        def model_name
          if Ractor.main?
            @_model_name ||= _rrs_compute_model_name
          else
            store = (RactorRailsShim.storage[:rrs_model_names] ||= {})
            store[object_id] ||= _rrs_compute_model_name
          end
        end

        private

        def _rrs_compute_model_name
          namespace = module_parents.detect do |n|
            n.respond_to?(:use_relative_model_naming?) && n.use_relative_model_naming?
          end
          ::ActiveModel::Name.new(self, namespace)
        end
      end

      # Frozen-safe lazy memos on ActiveModel::Name (i18n_keys / i18n_scope).
      # Error-message generation (Errors#generate_message ->
      # model_name.human) reads these; the upstream `@i18n_keys ||=` is a
      # memo WRITE that raises FrozenError on a Name instance frozen by
      # make_app_shareable! (the Name is reachable from the frozen class
      # graph via @_model_name). Workers are covered by the per-Ractor
      # model_name store above (fresh mutable Names); this patch covers MAIN
      # after the freeze and any other frozen Name. Compute without the memo
      # write when the memo is unset and the receiver is frozen.
      nm = ::ActiveModel::Name
      unless nm.method_defined?(:_rrs_orig_i18n_keys)
        nm.class_eval <<-RUBY, __FILE__, __LINE__ + 1
          alias_method :_rrs_orig_i18n_keys, :i18n_keys
          def i18n_keys
            return _rrs_orig_i18n_keys if !frozen? || instance_variable_defined?(:@i18n_keys)
            @klass.respond_to?(:lookup_ancestors) ?
              @klass.lookup_ancestors.map { |k| k.model_name.i18n_key } : []
          end

          alias_method :_rrs_orig_i18n_scope, :i18n_scope
          def i18n_scope
            return _rrs_orig_i18n_scope if !frozen? || instance_variable_defined?(:@i18n_scope)
            @klass.respond_to?(:i18n_scope) ? [@klass.i18n_scope, :models] : []
          end
          private :i18n_keys, :i18n_scope
        RUBY
      end
    end

    # Patch ActiveRecord::ModelSchema::ClassMethods lazy class-ivar caches
    # (`symbol_column_to_string`, `content_columns`, `column_defaults`) to
    # route through IsolatedExecutionState. Each Ractor builds its own cache
    # (deterministic from `columns`/`columns_hash`, which are warmed in main
    # and read-only in workers). Without this, the first worker call that
    # misses the cache tries to WRITE the class ivar (`@symbol_column_to_string_name_hash
    # ||= ...`) and dies with `Ractor::IsolationError: can not set instance
    # variables of classes/modules by non-main Ractors`. Seen via Devise's
    # `clean_up_passwords` -> `respond_to?` -> `symbol_column_to_string`.
    def _install_activerecord_model_schema_patch
      return if @ar_model_schema_symbol_patched
      @ar_model_schema_symbol_patched = true
      _register_patch :activerecord_model_schema, "8.1"
      return unless defined?(::ActiveRecord::ModelSchema)

      ::ActiveRecord::ModelSchema::ClassMethods.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def symbol_column_to_string(name_symbol)
          key = :"ractor_rails_shim_symbol_column_to_string_\#{self.name}"
          v = RactorRailsShim.storage[key]
          return v[name_symbol] if v
          hash = column_names.index_by(&:to_sym)
          RactorRailsShim.storage[key] = hash
          hash[name_symbol]
        end

        def content_columns
          key = :"ractor_rails_shim_content_columns_\#{self.name}"
          v = RactorRailsShim.storage[key]
          return v if v
          cols = columns.reject do |c|
            c.name == primary_key ||
            c.name == inheritance_column ||
            c.name.end_with?("_id", "_count")
          end.freeze
          RactorRailsShim.storage[key] = cols
          cols
        end

        # In a worker Ractor, load_schema and load_schema! must not write
        # class ivars (@columns_hash, @schema_loaded, etc.). The schema was
        # loaded in the main Ractor and the values are either frozen in the
        # shared graph or routed through IES. Patch load_schema to no-op in
        # workers (the schema is already loaded), and load_schema! to be a
        # no-op (never called from a worker because load_schema short-circuits).
        alias_method :_rrs_orig_load_schema, :load_schema
        def load_schema
          return unless Ractor.main?
          _rrs_orig_load_schema
        end

        alias_method :_rrs_orig_load_schema_bang, :load_schema!
        def load_schema!
          return unless Ractor.main?
          _rrs_orig_load_schema_bang
        end

        # NOTE: `column_defaults` is intentionally NOT redefined here. It is
        # installed by the prepended `ActiveRecordModelSchemaPatch` (see
        # `active_record_model_schema.rb`), which is prepended onto
        # `ModelSchema::ClassMethods` by `_install_active_model_attribute_patch`
        # and therefore sits in front of this module_eval heredoc in the
        # method lookup chain. A second definition here would be dead code and
        # a maintenance trap.

        # `reload_schema_from_cache` (called by `load_schema`/`reload_schema!`)
        # writes a batch of class ivars to `nil` to invalidate schema caches:
        #   @_returning_columns_for_insert, @arel_table, @column_names,
        #   @symbol_column_to_string_name_hash, @content_columns, @column_defaults
        # (ModelSchema) plus @timestamp_attributes_for_create_in_model,
        # @timestamp_attributes_for_update_in_model,
        # @all_timestamp_attributes_in_model (Timestamp#reload_schema_from_cache
        # via super). In a worker Ractor those writes raise
        # Ractor::IsolationError ("can not set instance variables of
        # classes/modules by non-main Ractors"). The shim already routes the
        # *readers* for these caches through IES, so in a worker we only need
        # to clear the IES slots — the next read rebuilds lazily. In main we
        # keep the original class-ivar-clearing behavior.
        alias_method :_rrs_orig_reload_schema_from_cache, :reload_schema_from_cache
        def reload_schema_from_cache(recursive = true)
          if Ractor.main?
            # During warming (prepare_for_ractors!/make_app_shareable!),
            # reload_schema_from_cache on abstract parents recursively resets
            # @schema_loaded = false and @columns_hash = nil on all descendants,
            # destroying schema data that workers need. Use a module-level flag
            # to suppress the recursive reset during the warming phase. The
            # flag is set by _share_model_classes! and generate_ar_attribute_methods!.
            unless RactorRailsShim.instance_variable_get(:@_rrs_schema_warming)
              _rrs_orig_reload_schema_from_cache(recursive)
            end
          else
            # Clear this Ractor's IES slots for the IES-routed schema caches.
            # Use `next` over an explicit list (not `IES.clear`) to avoid
            # wiping unrelated slots. Keys mirror the readers above + the
            # prepended ActiveRecordModelSchemaPatch (active_record_model_schema.rb)
            # + ActiveModelAttributeRegistrationPatch (active_model_attribute.rb).
            name_str = self.name
            [
              :"ractor_rails_shim_symbol_column_to_string_\#{name_str}",
              :"ractor_rails_shim_content_columns_\#{name_str}",
              :"rrs_column_defaults_\#{object_id}",
              :"rrs_attributes_builder_\#{object_id}",
              :"rrs_yaml_encoder_\#{object_id}",
              :"rrs_returning_cols_\#{object_id}",
              :"rrs_default_attributes_\#{object_id}",
              :"rrs_attribute_types_\#{object_id}",
              :"rrs_table_names",
              :"rrs_arel_tables",
              :"rrs_predicate_builders",
              :"rrs_type_casters",
            ].each do |k| RactorRailsShim.storage.delete(k) end
            # The Timestamp subclass override calls `super` (this method); it
            # has already run by the time we get here via the super chain, so
            # its ivar-clears were intercepted by the worker branch of THIS
            # override (no-op). No further action needed.
          end
        end
      RUBY

      # Patch ActiveRecord::Timestamp::ClassMethods#reload_schema_from_cache
      # the same way: in main, keep the original ivar-clearing; in a worker,
      # skip the class-ivar writes (the IES slots are cleared by the
      # ModelSchema#reload_schema_from_cache override above via super).
      if defined?(::ActiveRecord::Timestamp::ClassMethods)
        ::ActiveRecord::Timestamp::ClassMethods.module_eval <<-RUBY, __FILE__, __LINE__ + 1
          def reload_schema_from_cache(recursive = true)
            if Ractor.main?
              @timestamp_attributes_for_create_in_model = nil
              @timestamp_attributes_for_update_in_model = nil
              @all_timestamp_attributes_in_model = nil
              super
            else
              # Worker: skip the class-ivar writes (would raise
              # IsolationError). The ModelSchema super clears the IES slots.
              super
            end
          end

          # The three timestamp-attribute readers memoize their result on the
          # (shared, frozen) model class via @timestamp_attributes_for_* class
          # ivars. From a worker Ractor that write raises Ractor::IsolationError
          # (this is exactly the failure hit on Comment#save ->
          # _create_record -> all_timestamp_attributes_in_model). Route the
          # memoization through a per-worker cache in workers; keep the original
          # class-ivar behavior in main (where the value is frozen into the
          # shared graph and the ivar can still be written before freeze).
          def timestamp_attributes_for_create_in_model
            if Ractor.main?
              @timestamp_attributes_for_create_in_model ||=
                (timestamp_attributes_for_create & column_names).freeze
            else
              (Ractor.current[:__rrs_ts_cache__] ||= {})[[object_id, :ts_create]] ||=
                (timestamp_attributes_for_create & column_names).freeze
            end
          end

          def timestamp_attributes_for_update_in_model
            if Ractor.main?
              @timestamp_attributes_for_update_in_model ||=
                (timestamp_attributes_for_update & column_names).freeze
            else
              (Ractor.current[:__rrs_ts_cache__] ||= {})[[object_id, :ts_update]] ||=
                (timestamp_attributes_for_update & column_names).freeze
            end
          end

          def all_timestamp_attributes_in_model
            if Ractor.main?
              @all_timestamp_attributes_in_model ||=
                (timestamp_attributes_for_create_in_model + timestamp_attributes_for_update_in_model).freeze
            else
              (Ractor.current[:__rrs_ts_cache__] ||= {})[[object_id, :ts_all]] ||=
                (timestamp_attributes_for_create_in_model + timestamp_attributes_for_update_in_model).freeze
            end
          end
        RUBY
      end
    end

    # Patch ActiveModel::Conversion::ClassMethods#_to_partial_path to route its
    # lazy class-ivar cache (`@_to_partial_path ||= ...`) through
    # IsolatedExecutionState. The cache holds a deterministic String derived
    # from `model_name`, so each Ractor can build its own. Without this, the
    # first `render @posts` / `render post` in a worker Ractor writes the class
    # ivar and dies with `Ractor::IsolationError: can not set instance variables
    # of classes/modules by non-main Ractors`. Seen via ActionView's
    # `CollectionRenderer#render_collection_derive_partial` -> `to_partial_path`.
    def _install_active_model_conversion_patch
      return if @active_model_conversion_patched
      @active_model_conversion_patched = true
      _register_patch :active_model_conversion, "8.1"
      return unless defined?(::ActiveModel::Conversion)
      amc = ::ActiveModel::Conversion
      amc.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        module ClassMethods
          def _to_partial_path
            key = :"ractor_rails_shim_to_partial_path_\#{name}"
            v = RactorRailsShim.storage[key]
            return v if v
            path = if respond_to?(:model_name)
              "\#{model_name.collection}/\#{model_name.element}"
            else
              element = ActiveSupport::Inflector.underscore(ActiveSupport::Inflector.demodulize(name))
              collection = ActiveSupport::Inflector.tableize(name)
              "\#{collection}/\#{element}"
            end
            path = path.freeze
            RactorRailsShim.storage[key] = path
            path
          end
        end
      RUBY
    end

    # Patch ActiveRecord::Core.configurations / configurations= to route the
    # raw `@@configurations` class variable (which a non-main Ractor cannot
    # read or write) through IsolatedExecutionState, with a shareable
    # (deep-frozen) fallback for worker Ractors. Connection establishment in a
    # worker (`ConnectionHandler#establish_connection` -> `resolve_pool_config`
    # -> `ActiveRecord::Base.configurations`) otherwise dies on the class
    # variable. Captured in the main Ractor at prepare/make-shareable time.
    def _install_activerecord_configurations_patch
      return if @ar_configurations_patched
      @ar_configurations_patched = true
      _register_patch :activerecord_configurations, "8.1"
      return unless defined?(::ActiveRecord::Core)

      if Ractor.main?
        begin
          cfg = ::ActiveRecord::Base.configurations
          cfg = Ractor.make_shareable(cfg) if cfg
          if cfg
            _reassign_shareable_const(:AR_CONFIGURATIONS_SHAREABLE, cfg)
          end
        rescue StandardError => e
          # best-effort
        end
      end

      key = :ractor_rails_shim_ar_configurations
      key_str = key.inspect
      # ActiveRecord::Base gets `configurations` via ActiveSupport::Concern's
      # `class_methods` (it copies the method onto Base's singleton class), so
      # patching Core.singleton_class alone is not enough — redefine on Base's
      # singleton class directly. `@@configurations` resolves through the
      # include chain (Core's class var) in the main ractor; the worker branch
      # never touches the class var.
      ::ActiveRecord::Base.singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def configurations
          v = RactorRailsShim.storage[#{key_str}]
          return v unless v.nil?
          return nil if RactorRailsShim.storage.key?(#{key_str})
          if Ractor.main?
            ActiveRecord::Core.class_variable_get(:@@configurations)
          else
            RactorRailsShim::AR_CONFIGURATIONS_SHAREABLE
          end
        end
        def configurations=(config)
          RactorRailsShim.storage[#{key_str}] = config
          ActiveRecord::Core.class_variable_set(:@@configurations, config) if Ractor.main?
        end
      RUBY
    end

    # Patch ActiveRecord::DatabaseConfigurations.db_config_handlers (a
    # `singleton_class.attr_accessor`, i.e. a class instance variable on the
    # DatabaseConfigurations class) to route through IES with a shareable
    # fallback. The value is an Array of adapter-registered handler Procs
    # (`register_db_config_handler { |env,name,url,config| ... }`). Class
    # instance variables are per-Ractor, so a worker's slot is empty even if
    # main set one — and the worker cannot read main's. The handler Procs
    # themselves CAN be made shareable (verified: the sqlite3 handler captures
    # only the shareable HashConfig constant), so we deep-freeze the Array +
    # each Proc in main and expose it as a shareable constant the worker reads.
    # `ConnectionHandler#establish_connection` -> `resolve_pool_config` ->
    # `DatabaseConfigurations#resolve` -> `build_db_config_from_hash` calls
    # these Procs, so they must be shareable AND callable cross-Ractor.
    def _install_activerecord_db_config_handlers_patch
      return if @ar_dbch_patched
      @ar_dbch_patched = true
      _register_patch :activerecord_db_config_handlers, "8.1"
      return unless defined?(::ActiveRecord::DatabaseConfigurations)

      if Ractor.main?
        begin
          handlers = ::ActiveRecord::DatabaseConfigurations.db_config_handlers
          # Make each handler Proc shareable (freezes its binding). A shareable
          # Proc is callable from any Ractor.
          handlers.each { |h| _swallow("make ar db config handler shareable") { Ractor.make_shareable(h) } }
          shareable = Ractor.make_shareable(handlers.dup)
          _reassign_shareable_const(:AR_DB_CONFIG_HANDLERS_SHAREABLE, shareable)
        rescue StandardError => e
          # best-effort
        end
      end

      key = :ractor_rails_shim_ar_db_config_handlers
      key_str = key.inspect
      ::ActiveRecord::DatabaseConfigurations.singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def db_config_handlers
          v = RactorRailsShim.storage[#{key_str}]
          return v unless v.nil?
          return nil if RactorRailsShim.storage.key?(#{key_str})
          if Ractor.main?
            @db_config_handlers
          else
            RactorRailsShim::AR_DB_CONFIG_HANDLERS_SHAREABLE
          end
        end
        def db_config_handlers=(val)
          RactorRailsShim.storage[#{key_str}] = val
          @db_config_handlers = val if Ractor.main?
        end
      RUBY
    end

    # Patch ActiveRecord.query_transformers to route through IES with a
    # shareable fallback. `query_transformers` is a `singleton_class
    # .attr_accessor` (a class instance variable on the `ActiveRecord` module)
    # holding an Array of transformer objects (e.g. `ActiveRecord::QueryLogs`).
    # `DatabaseStatements#preprocess_query` reads it on every query:
    # `ActiveRecord.query_transformers.each { |t| t.call(sql, self) }`.
    #
    # Class instance variables are per-Ractor, so a worker's `@query_transformers`
    # is nil (set in main at boot via `self.query_transformers = []`, then
    # `<< QueryLogs` in the railtie). The transformer objects themselves ARE
    # shareable (they're Classes/modules), so we deep-freeze the Array in main
    # and expose it as a shareable constant the worker reads. Same pattern as
    # `_install_activerecord_db_config_handlers_patch`.
    def _install_activerecord_query_transformers_patch
      return if @ar_query_transformers_patched
      @ar_query_transformers_patched = true
      _register_patch :activerecord_query_transformers, "8.1"
      return unless defined?(::ActiveRecord)

      if Ractor.main?
        begin
          transformers = ::ActiveRecord.query_transformers
          transformers.each { |t| _swallow("make ar query transformer shareable") { Ractor.make_shareable(t) } }
          shareable = Ractor.make_shareable(transformers.dup)
          _reassign_shareable_const(:AR_QUERY_TRANSFORMERS_SHAREABLE, shareable)
        rescue StandardError => e
          # best-effort
        end
      end

      key = :ractor_rails_shim_ar_query_transformers
      key_str = key.inspect
      ::ActiveRecord.singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def query_transformers
          v = RactorRailsShim.storage[#{key_str}]
          return v unless v.nil?
          return nil if RactorRailsShim.storage.key?(#{key_str})
          if Ractor.main?
            @query_transformers
          else
            RactorRailsShim::AR_QUERY_TRANSFORMERS_SHAREABLE
          end
        end
        def query_transformers=(val)
          RactorRailsShim.storage[#{key_str}] = val
          @query_transformers = val if Ractor.main?
        end
      RUBY
    end

    # Patch ActiveRecord module-level singleton_class.attr_accessor attributes
    # (schema_cache_ignored_tables, database_cli, etc.) to route through IES
    # with shareable fallbacks. These are class instance variables on the
    # `ActiveRecord` module that workers can't read/write. Each is an Array or
    # Hash of simple literals, so they can be deep-frozen and shared.
    def _install_activerecord_module_attrs_patch
      return if @ar_module_attrs_patched
      @ar_module_attrs_patched = true
      _register_patch :activerecord_module_attrs, "8.1"
      return unless defined?(::ActiveRecord)

      # [method_name, const_name] pairs. The const holds the shareable snapshot.
      attrs = [
        [:schema_cache_ignored_tables, :AR_SCHEMA_CACHE_IGNORED_TABLES_SHAREABLE],
        [:database_cli, :AR_DATABASE_CLI_SHAREABLE],
      ]

      attrs.each do |method_name, const_name|
        if Ractor.main?
          begin
            val = ::ActiveRecord.public_send(method_name)
            shareable = Ractor.make_shareable(val.is_a?(::Array) ? val.dup : val)
            _reassign_shareable_const(const_name, shareable)
          rescue StandardError => e
            # best-effort
          end
        end

        key = :"ractor_rails_shim_ar_#{method_name}"
        key_str = key.inspect
        const_str = const_name.to_s
        ::ActiveRecord.singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
          def #{method_name}
            v = RactorRailsShim.storage[#{key_str}]
            return v unless v.nil?
            return nil if RactorRailsShim.storage.key?(#{key_str})
            if Ractor.main?
              @#{method_name}
            else
              RactorRailsShim::#{const_str}
            end
          end
          def #{method_name}=(val)
            RactorRailsShim.storage[#{key_str}] = val
            @#{method_name} = val if Ractor.main?
          end
        RUBY
      end
    end

    # Patch Deduplicable::ClassMethods#registry to route the lazy class instance
    # variable @registry through IES. `registry` returns `@registry ||= {}` —
    # a mutable Hash used to deduplicate column metadata objects. It's called
    # during schema introspection (`Post.all` -> `columns` -> `new_column_from_field`
    # -> `fetch_type_metadata` -> `Deduplicable.new` -> `deduplicate` -> `registry`).
    # The class instance variable write fails from a non-main Ractor.
    # Fix: route through IES so each Ractor builds its own registry Hash.
    def _install_activerecord_deduplicable_patch
      return if @ar_deduplicable_patched
      @ar_deduplicable_patched = true
      _register_patch :activerecord_deduplicable, "8.1"
      return unless defined?(::ActiveRecord::ConnectionAdapters::Deduplicable)

      ::ActiveRecord::ConnectionAdapters::Deduplicable::ClassMethods.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def registry
          key = :"ractor_rails_shim_dedup_registry_\#{name || object_id}"
          v = RactorRailsShim.storage[key]
          return v unless v.nil?
          return nil if RactorRailsShim.storage.key?(key)
          h = {}
          RactorRailsShim.storage[key] = h
          h
        end
      RUBY
    end

    # Patch Persistence::ClassMethods#query_constraints_list and #has_query_constraints?
    # to route the lazy @query_constraints_list class ivar through IES.
    # `query_constraints_list` does `@query_constraints_list ||= <computation>`
    # — the class ivar write fails from a non-main Ractor. Called during
    # `Post.first` -> `ordered_relation` -> `_order_columns`.
    def _install_activerecord_query_constraints_patch
      return if @ar_query_constraints_patched
      @ar_query_constraints_patched = true
      _register_patch :activerecord_query_constraints, "8.1"
      return unless defined?(::ActiveRecord::Persistence::ClassMethods)

      ::ActiveRecord::Persistence::ClassMethods.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def query_constraints_list
          key = :"ractor_rails_shim_qcl_\#{name || object_id}"
          v = RactorRailsShim.storage[key]
          return v unless v.nil?
          return nil if RactorRailsShim.storage.key?(key)
          result = if base_class? || primary_key != base_class.primary_key
            primary_key if primary_key.is_a?(::Array)
          else
            base_class.query_constraints_list
          end
          RactorRailsShim.storage[key] = result
          result
        end
        def has_query_constraints?
          key = :"ractor_rails_shim_qcl_\#{name || object_id}"
          v = RactorRailsShim.storage[key]
          return !v.nil? if RactorRailsShim.storage.key?(key)
          result = query_constraints_list
          !result.nil?
        end
      RUBY
    end

    # Patch ActiveRecord::ConnectionAdapters::PoolConfig#initialize to skip
    # writing to the INSTANCES ObjectSpace::WeakMap registry in non-main
    # Ractors. This is the first wall a worker hits when establishing a
    # connection (`ConnectionHandler#establish_connection` ->
    # `resolve_pool_config` -> `PoolConfig.new` -> `INSTANCES[self] = self`).
    #
    # `INSTANCES` is a `private_constant` `ObjectSpace::WeakMap`. A WeakMap is
    # intrinsically unshareable (it can't be frozen / made shareable), and a
    # non-main Ractor cannot access the constant at all (Ractor::IsolationError:
    # "can not access non-shareable objects in constant ... by non-main ractor").
    #
    # The registry is ONLY used by the class methods `discard_pools!` and
    # `disconnect_all!` (which iterate all pool configs to disconnect/reload).
    # Those are called during reloading (dev) and explicit disconnect — never
    # in a read-only production worker serving requests. So skipping the
    # registry write in workers is safe: workers manage their own per-Ractor
    # handler + pools, and the main ractor's registry stays intact for reload.
    #
    # We redefine `initialize` via string eval (no captured binding) so it's
    # callable from any Ractor. The body replicates the original exactly except
    # the final `INSTANCES[self] = self` is guarded by `Ractor.main?`. The
    # private `INSTANCES` constant is accessible via constant lookup because
    # the method is defined on PoolConfig itself.
    def _install_activerecord_pool_config_patch
      return if @ar_pool_config_patched
      @ar_pool_config_patched = true
      _register_patch :activerecord_pool_config, "8.1"
      return unless defined?(::ActiveRecord::ConnectionAdapters::PoolConfig)

      ::ActiveRecord::ConnectionAdapters::PoolConfig.class_eval <<-RUBY, __FILE__, __LINE__ + 1
        def initialize(connection_class, db_config, role, shard)
          super()
          @server_version = nil
          self.connection_descriptor = connection_class
          @db_config = db_config
          @role = role
          @shard = shard
          @pool = nil
          INSTANCES[self] = self if Ractor.main?
        end
      RUBY
    end

    # Patch ConnectionPool::Reaper#run to no-op in non-main Ractors.
    #
    # `ConnectionPool#initialize` (connection_pool.rb:307) calls `@reaper.run`,
    # which calls `Reaper.register_pool` (a class method). `register_pool`
    # reads/writes the Reaper class's instance variables (@mutex, @pools,
    # @threads — a Mutex, a Hash, and a Hash of Threads) and spawns a
    # background reaper thread. Class instance variables are off-limits to
    # non-main Ractors (Ractor::IsolationError), so this is the second wall a
    # worker hits during `establish_connection` -> `ConnectionPool.new`.
    #
    # The reaper is a background maintenance thread that periodically reaps
    # dead-thread connections, flushes idle connections, and keepalives stale
    # ones. In a worker Ractor this is neither safe (can't share the reaper
    # thread or its class-ivar registry across Ractors) nor essential: each
    # Ractor owns its own connection pool, and when the Ractor exits its pool
    # is garbage-collected with it. Connection health for long-lived workers
    # can be addressed later with a per-Ractor reaper if needed; for now,
    # no-op'ing registration unblocks connection establishment.
    #
    # `register_pool` is only called from `Reaper#run`, so patching `run` to
    # return early in non-main Ractors fully prevents the class-ivar access and
    # the thread spawn. The pool itself still functions normally.
    def _install_activerecord_reaper_patch
      return if @ar_reaper_patched
      @ar_reaper_patched = true
      _register_patch :activerecord_reaper, "8.1"
      return unless defined?(::ActiveRecord::ConnectionAdapters::ConnectionPool::Reaper)

      ::ActiveRecord::ConnectionAdapters::ConnectionPool::Reaper.class_eval <<-RUBY, __FILE__, __LINE__ + 1
        def run
          return unless frequency && frequency > 0
          return unless Ractor.main?
          self.class.register_pool(pool, frequency)
        end
      RUBY
    end

    # Patch Arel::Visitors::Visitor.dispatch_cache to route through IES.
    #
    # `dispatch_cache` is a class method that lazily initializes a class
    # instance variable: `@dispatch_cache ||= Hash.new { |hash, klass| ... }
    # .compare_by_identity`. The cache maps AST node classes to visit method
    # symbols (e.g. Arel::Nodes::SelectStatement -> :visit_Arel_Nodes_SelectStatement).
    # It's read on every Arel traversal (every query) and written on cache-miss
    # (default proc) and on method-not-found fallback (visit() rescue).
    #
    # The class instance variable `@dispatch_cache` can't be read or written by
    # a non-main Ractor (Ractor::IsolationError). The Hash also has a default
    # Proc (which is intrinsically unshareable), so the value can't be
    # frozen+shared. This is the third wall a worker hits during the first
    # query: `Post.count` -> adapter creation -> `arel_visitor` ->
    # `ToSql#initialize` -> `Visitor#initialize` -> `get_dispatch_cache` ->
    # `self.class.dispatch_cache` -> `@dispatch_cache ||= ...`.
    #
    # Fix: route through per-class IES. Each Ractor builds its own mutable
    # cache (with its own default proc) on first access. The key includes
    # `self.name` so each visitor subclass (ToSql, SQLite3, etc.) gets its own
    # cache — necessary because the method-not-found fallback
    # (`dispatch[object.class] = dispatch[superklass]`) resolves differently per
    # visitor class. The main ractor's existing `@dispatch_cache` (if any) is
    # left orphaned; new visitors created after the patch use the IES cache.
    # String-eval'd (no captured binding), callable from any Ractor.
    def _install_arel_visitor_dispatch_cache_patch
      return if @arel_visitor_patched
      @arel_visitor_patched = true
      _register_patch :arel_visitor_dispatch_cache, "8.1"
      return unless defined?(::Arel::Visitors::Visitor)

      ::Arel::Visitors::Visitor.singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def dispatch_cache
          key = :"ractor_rails_shim_arel_dispatch_\#{name || object_id}"
          v = RactorRailsShim.storage[key]
          return v if v
          cache = Hash.new do |hash, klass|
            hash[klass] = :"visit_\#{(klass.name || "").gsub("::", "_")}"
          end.compare_by_identity
          RactorRailsShim.storage[key] = cache
          cache
        end
      RUBY
    end

    # Patch the adapter quoting caches (QUOTED_COLUMN_NAMES /
    # QUOTED_TABLE_NAMES) to use per-Ractor storage instead of the
    # unshareable `Concurrent::Map` constants.
    #
    # Each adapter (SQLite3, MySQL, PostgreSQL) defines these as
    # `Concurrent::Map.new` constants in its `Quoting` module, and the
    # `quote_column_name` / `quote_table_name` class methods lazily populate
    # them via `MAP[name] ||= <quoting_logic>.freeze`. `Concurrent::Map` is
    # intrinsically unshareable (no `#freeze`), so a worker Ractor cannot
    # access the constant at all (Ractor::IsolationError: "can not access
    # non-shareable objects in constant ..."). This is the fourth wall a worker
    # hits: during `Post.count` -> Arel traversal -> `quote_table_name` ->
    # `QUOTED_TABLE_NAMES[name] ||= ...`.
    #
    # Fix: redefine `quote_column_name` / `quote_table_name` on each adapter's
    # `Quoting::ClassMethods` module to use a per-Ractor Hash cache (stored in
    # IES, keyed by the adapter class name). Each Ractor builds its own
    # mutable cache on first access. The quoting logic is replicated per
    # adapter (it's simple, stable string manipulation). String-eval'd (no
    # captured binding), callable from any Ractor.
    def _install_activerecord_quoting_cache_patch
      return if @ar_quoting_patched
      @ar_quoting_patched = true
      _register_patch :activerecord_quoting_cache, "8.1"

      # [module_path, column_logic, table_logic] per adapter.
      adapters = [
        ["ActiveRecord::ConnectionAdapters::SQLite3::Quoting",
         %q{%Q("#{name.to_s.gsub('"', '""')}").freeze},
         %q{%Q("#{name.to_s.gsub('"', '""').gsub(".", "\".\"")}").freeze}],
        ["ActiveRecord::ConnectionAdapters::MySQL::Quoting",
         %q{"`#{name.to_s.gsub('`', '``')}`".freeze},
         %q{"`#{name.to_s.gsub('`', '``').gsub(".", "`.`")}`".freeze}],
        ["ActiveRecord::ConnectionAdapters::PostgreSQL::Quoting",
         %q{::PG::Connection.quote_ident(name.to_s).freeze},
         %q{::ActiveRecord::ConnectionAdapters::PostgreSQL::Utils.extract_schema_qualified_name(name.to_s).quoted.freeze}],
      ]

      adapters.each do |mod_path, column_logic, table_logic|
        mod = begin
          mod_path.split("::").inject(Object) { |ns, n| ns.const_get(n, false) }
        rescue StandardError
          nil
        end
        next unless mod
        klass_mod = mod.const_get(:ClassMethods, false) rescue next
        next unless klass_mod.method_defined?(:quote_column_name)

        klass_mod.module_eval <<-RUBY, __FILE__, __LINE__ + 1
          def quote_column_name(name)
            key = :"ractor_rails_shim_quoted_cols_\#{self.name}"
            cache = RactorRailsShim.storage[key]
            cache ||= (RactorRailsShim.storage[key] = {})
            cache[name] ||= (#{column_logic})
          end

          def quote_table_name(name)
            key = :"ractor_rails_shim_quoted_tables_\#{self.name}"
            cache = RactorRailsShim.storage[key]
            cache ||= (RactorRailsShim.storage[key] = {})
            cache[name] ||= (#{table_logic})
          end
        RUBY
      end
    end

    # Patch ActiveRecord::Base to route default_connection_handler through
    # IES, and ensure connection_handler returns the per-Ractor handler.
    # In the main ractor, falls back to the original default_connection_handler
    # (set at core.rb:248). In workers, falls back to nil (correct — workers
    # must call init_worker_ar_connections! to establish their own handler).
    # Also patches retrieve_connection / connected? / connection_pool to
    # tolerate nil handler (raise a clear error message instead of
    # NoMethodError on nil).
    def _install_activerecord_connection_handler_patch
      return if @ar_conn_handler_patched
      @ar_conn_handler_patched = true
      _register_patch :activerecord_connection_handler, "8.1"
      return unless defined?(::ActiveRecord::ConnectionHandling)

      # Capture configs at install time if AR is already loaded (main ractor).
      _capture_ar_configurations! if Ractor.main?

      # Capture the main ractor's default_connection_handler value BEFORE we
      # override the method below (the override shadows the original
      # class_attribute reader). The class_attribute reader (already patched
      # by the shim) routes through IES, so read the value now. Store it in
      # CLASS_ATTR_VALUES so the patched reader can find it, and seed IES so
      # connection_handler finds it immediately.
      dch_key = :ractor_rails_shim_ar_default_connection_handler
      dch_key_str = dch_key.inspect
      if Ractor.main?
        begin
          orig_handler = ::ActiveRecord::Base.default_connection_handler
          if orig_handler
            RactorRailsShim::Registry.class_attr_values[:__ractor_rails_shim_ar_default_connection_handler__] = orig_handler
            RactorRailsShim.storage[dch_key] = orig_handler
          end
        rescue StandardError => e
          # Best-effort
        end
      end

      # Patch default_connection_handler to route through IES.
      # The class_attribute reader for default_connection_handler is already
      # patched by the shim (it's in the known-unshareable skip list → nil
      # in workers). We override the class method to return the per-Ractor
      # handler if set, then fall back to the original (main only) or nil.
      ::ActiveRecord::Base.singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def default_connection_handler
          v = RactorRailsShim.storage[#{dch_key_str}]
          return v unless v.nil?
          return nil if RactorRailsShim.storage.key?(#{dch_key_str})
          if Ractor.main?
            cv = RactorRailsShim::CLASS_ATTR_VALUES[:__ractor_rails_shim_ar_default_connection_handler__]
            return cv if cv
          end
          nil
        end
        def default_connection_handler=(val)
          RactorRailsShim.storage[#{dch_key_str}] = val
        end
        # Route the per-Ractor handler through Ractor-local storage. IES is
        # per-thread, so a handler stored on the init thread is invisible to the
        # worker's other threads; Ractor.current is per-Ractor and shared by all
        # threads of the worker. Falls back to IES (legacy) then
        # default_connection_handler (main Ractor only).
        # NOTE: uses nil-sentinel (`unless v.nil?`) rather than key?-based
        # detection because Ractor#[] has no `key?` method (Ractor local
        # storage returns nil for both unset and set-to-nil). Safe here
        # because `connection_handler=` is only ever called with a real
        # ConnectionHandler instance, never nil — so nil unambiguously
        # means "unset, fall through to default_connection_handler".
        def connection_handler
          v = Ractor.current[:active_record_connection_handler]
          return v unless v.nil?
          RactorRailsShim.storage[:active_record_connection_handler] || default_connection_handler
        end
        def connection_handler=(handler)
          Ractor.current[:active_record_connection_handler] = handler
        end
      RUBY

      # Also ensure connection_handler (which Rails already routes through IES
      # at core.rb:132-138) works. Rails' implementation:
      #   def self.connection_handler
      #     RactorRailsShim.storage[:active_record_connection_handler] || default_connection_handler
      #   end
      # This is already correct — if the worker sets the IES key via
      # init_worker_ar_connections!, connection_handler returns it. If not,
      # it falls back to default_connection_handler (nil in workers).
      #
      # We just need to make sure connection_pool / retrieve_connection
      # give a clear error message when the handler is nil (instead of
      # NoMethodError: undefined method `retrieve_connection_pool' for nil).
      ::ActiveRecord::ConnectionHandling.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def connection_pool
          handler = connection_handler
          unless handler
            raise ActiveRecord::ConnectionNotEstablished,
              "No connection handler for Ractor \#{Ractor.current.object_id}. " \
              "Call RactorRailsShim.init_worker_ar_connections! in each worker " \
              "Ractor before serving requests."
          end
          handler.retrieve_connection_pool(connection_specification_name, role: current_role, shard: current_shard, strict: true)
        rescue ::ActiveRecord::ConnectionNotDefined
          # connects_to-style models (Solid Cache / Solid Queue / Solid Cable)
          # own their pool in the MAIN handler — registered under their CLASS
          # name (connects_to sets @connection_specification_name) — but
          # init_worker_ar_connections! only seeds Base-level pools. Fall back
          # to the Base pool for the same role/shard: for the standard pattern
          # (shard key == database.yml name, e.g. SolidCache::Record's
          # default_shard == :primary from config/cache.yml `database:
          # primary`) the seed step registered exactly that (role, shard) pair
          # under the Base manager, pointing at the same db_config as the
          # class-owned pool in main.
          handler.retrieve_connection_pool(::ActiveRecord::Base.name, role: current_role, shard: current_shard, strict: true)
        end
        def retrieve_connection
          handler = connection_handler
          unless handler
            raise ActiveRecord::ConnectionNotEstablished,
              "No connection handler for Ractor \#{Ractor.current.object_id}. " \
              "Call RactorRailsShim.init_worker_ar_connections! in each worker " \
              "Ractor before serving requests."
          end
          handler.retrieve_connection(connection_specification_name, role: current_role, shard: current_shard)
        rescue ::ActiveRecord::ConnectionNotDefined
          # See connection_pool above: connects_to-owned models resolve to the
          # Base-level pool for the same role/shard.
          handler.retrieve_connection(::ActiveRecord::Base.name, role: current_role, shard: current_shard)
        end
        def connected?
          handler = connection_handler
          return false unless handler
          handler.connected?(connection_specification_name, role: current_role, shard: current_shard) ||
            handler.connected?(::ActiveRecord::Base.name, role: current_role, shard: current_shard)
        end
      RUBY
    end

    # Patch ActiveModel::Type::SerializeCastValue::ClassMethods
    # #serialize_cast_value_compatible? to route the lazy class instance
    # variable @serialize_cast_value_compatible through IES.
    #
    # This method lazily caches a boolean: `return @x if defined?(@x); @x =
    # <computation>`. It's called during type-map initialization (every
    # adapter's `initialize_type_map` creates type objects whose constructors
    # eagerly call this to precompute the value). The class instance variable
    # write fails from a non-main Ractor (Ractor::IsolationError: "can not set
    # instance variables of classes/modules by non-main Ractors").
    #
    # Fix: route through IES so each Ractor computes + caches its own value.
    # The computation is deterministic (compares ancestor positions of two
    # methods), so per-Ractor recomputation yields the same result. Each
    # including class gets its own IES key (keyed by `self.name`). String-eval'd
    # (no captured binding), callable from any Ractor.
    def _install_activerecord_serialize_cast_value_patch
      return if @ar_serialize_cast_patched
      @ar_serialize_cast_patched = true
      _register_patch :activerecord_serialize_cast_value, "8.1"
      return unless defined?(::ActiveModel::Type::SerializeCastValue)

      ::ActiveModel::Type::SerializeCastValue::ClassMethods.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def serialize_cast_value_compatible?
          key = :"ractor_rails_shim_scv_\#{name || object_id}"
          v = RactorRailsShim.storage[key]
          return v unless v.nil?
          return nil if RactorRailsShim.storage.key?(key)
          result = begin
            ancestors.index(instance_method(:serialize_cast_value).owner) <= ancestors.index(instance_method(:serialize).owner)
          rescue ::RuntimeError, ::Ractor::Error
            # DelegateClass-built type classes (e.g. ActiveModel::Attributes::
            # Normalization::NormalizedValueType, used by `normalizes`) carry
            # Proc-body delegator methods created in main; Ruby 4 refuses
            # instance_method / instance_methods on such classes from a worker
            # ("defined with an un-shareable Proc in a different Ractor").
            # Recompute with own-table checks only — method_defined?(sym,
            # false) is a safe table read: find the first ancestor owning
            # serialize_cast_value vs the first owning serialize (same
            # owner-position comparison as upstream, without Method objects).
            scv_pos = ancestors.index { |m| (m.method_defined?(:serialize_cast_value, false) rescue false) }
            ser_pos = ancestors.index { |m| (m.method_defined?(:serialize, false) rescue false) }
            !scv_pos.nil? && (ser_pos.nil? || scv_pos <= ser_pos)
          end
          RactorRailsShim.storage[key] = result
          result
        end
      RUBY
    end

    # Patch ActiveRecord::Delegation.uncacheable_methods to route the lazy
    # class instance variable @uncacheable_methods through IES.
    #
    # `uncacheable_methods` is a class method on the `Delegation` module:
    # `@uncacheable_methods ||= (delegated_classes.flat_map(&:public_instance_methods)
    # - Relation.public_instance_methods).to_set.freeze`. It's read during
    # `method_missing` on relation delegate classes (e.g. when Kaminari calls
    # `Post.page(1).per(10)` — `per` isn't a standard Relation method, so
    # `ClassSpecificRelation#method_missing` checks `uncacheable_methods` to
    # decide whether to delegate). The class instance variable write fails
    # from a non-main Ractor (Ractor::IsolationError).
    #
    # Fix: route through IES so each Ractor computes + caches its own Set.
    # The computation is deterministic (same delegated_classes everywhere).
    # String-eval'd (no captured binding), callable from any Ractor.
    def _install_activerecord_delegation_patch
      return if @ar_delegation_patched
      @ar_delegation_patched = true
      _register_patch :activerecord_delegation, "8.1"
      return unless defined?(::ActiveRecord::Delegation)

      ::ActiveRecord::Delegation.singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def uncacheable_methods
          key = :ractor_rails_shim_ar_uncacheable_methods
          v = RactorRailsShim.storage[key]
          return v unless v.nil?
          return nil if RactorRailsShim.storage.key?(key)
          result = (
            delegated_classes.flat_map(&:public_instance_methods) - ActiveRecord::Relation.public_instance_methods
          ).to_set.freeze
          RactorRailsShim.storage[key] = result
          result
        end
      RUBY
    end

    # Patch ActiveRecord::AttributeMethods::PrimaryKey#primary_key and
    # #composite_primary_key? to not read the PRIMARY_KEY_NOT_SET constant.
    #
    # The original code: `reset_primary_key if PRIMARY_KEY_NOT_SET.equal?(@primary_key)`
    # reads the constant on every call. PRIMARY_KEY_NOT_SET is a BasicObject
    # (can't be frozen, can't be made shareable), so reading the constant from
    # a worker Ractor raises Ractor::IsolationError — even if @primary_key is
    # already set to the real value.
    #
    # Fix: replace the sentinel check with a shareable-snapshot lookup. At
    # _share_model_classes! time, each model's primary_key is warmed in main
    # and stored in AR_PRIMARY_KEYS_SHAREABLE (a frozen Hash). The patched
    # primary_key method checks IES first (per-Ractor), then the shareable
    # snapshot, then falls back to the original logic in the main ractor.
    # Workers never read the constant. String-eval'd (no captured binding).
    def _install_activerecord_primary_key_patch
      return if @ar_primary_key_patched
      @ar_primary_key_patched = true
      _register_patch :activerecord_primary_key, "8.1"
      return unless defined?(::ActiveRecord::AttributeMethods::PrimaryKey::ClassMethods)

      mod = ::ActiveRecord::AttributeMethods::PrimaryKey::ClassMethods
      mod.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def primary_key
          key = :"ractor_rails_shim_pk_\#{name || object_id}"
          v = RactorRailsShim.storage[key]
          return v unless v.nil?
          return nil if RactorRailsShim.storage.key?(key)
          if Ractor.main?
            reset_primary_key if PRIMARY_KEY_NOT_SET.equal?(@primary_key)
            v = @primary_key
            RactorRailsShim.storage[key] = v
            v
          else
            snap = RactorRailsShim::AR_PRIMARY_KEYS_SHAREABLE[name]
            return snap if snap
            # Fallback: derive the primary key from the schema cache via the
            # worker-safe table_name (compute_table_name). Reading the
            # @primary_key / @table_name class ivars raises
            # Ractor::IsolationError in workers, and the boot-time descendant
            # snapshot can miss lazy-loaded models, so compute it on demand.
            # `id` / `to_param` depend on primary_key, so a nil here breaks
            # URL helpers and record inspection in workers.
            begin
              pk = connection_pool.schema_cache.primary_keys(table_name)
              return pk if pk.is_a?(::String)
            rescue StandardError
              nil
            end
            nil
          end
        end
        def composite_primary_key?
          key = :"ractor_rails_shim_pk_\#{name || object_id}"
          v = RactorRailsShim.storage[key]
          return v.is_a?(::Array) if RactorRailsShim.storage.key?(key)
          if Ractor.main?
            reset_primary_key if PRIMARY_KEY_NOT_SET.equal?(@primary_key)
            @primary_key.is_a?(::Array)
          else
            pk = RactorRailsShim::AR_PRIMARY_KEYS_SHAREABLE[name]
            pk.is_a?(::Array)
          end
        end
      RUBY
    end

    # `ActiveRecord::Base#cached_find_by_statement` reads
    # `@find_by_statement_cache[connection.prepared_statements]` (a Hash whose
    # values are `Concurrent::Map`s) and calls `cache.compute_if_absent(key)`.
    # `Concurrent::Map` is unshareable, so `make_app_shareable!` replaces the
    # maps with frozen Hashes whose values end up `nil` — and `Hash` has no
    # `compute_if_absent` anyway. In a worker Ractor this raises
    # `NoMethodError: undefined method 'compute_if_absent' for nil`, breaking
    # `find` / `find_by` / `take` (but not `where`, which doesn't use the
    # cache). Fix: in non-main Ractors, build the per-find-statement cache in
    # `IsolatedExecutionState` (per-Ractor, mutable) keyed by the model class
    # and `connection.prepared_statements`. Main keeps the original
    # `Concurrent::Map`-backed behavior via `super`.
    def _install_activerecord_find_by_cache_patch
      return if @activerecord_find_by_cache_patched
      @activerecord_find_by_cache_patched = true
      _register_patch :activerecord_find_by_cache, "8.1"
      return unless defined?(::ActiveRecord::Base)

      ::ActiveRecord::Base.singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def cached_find_by_statement(connection, key, &block)
          return super if Ractor.main?
          cache = (RactorRailsShim.storage[:"ractor_rails_shim_find_by_cache_\#{object_id}"] ||= {})
          prepared = connection.prepared_statements
          sub = (cache[prepared] ||= {})
          if sub.key?(key)
            sub[key]
          else
            sub[key] = ::ActiveRecord::StatementCache.create(connection, &block)
          end
        end
      RUBY
    end

    # A shareable Rack middleware that ensures each worker Ractor establishes
    # its own ActiveRecord connection handler on the first request it serves.
    # Kino's `:ractor` mode has no per-worker init hook, so the connection
    # must be initialized lazily inside the worker Ractor's request path.
    # `init_worker_ar_connections!` is idempotent (it early-returns once the
    # per-Ractor IES slot holds a handler), so calling it on every request is
    # cheap after the first. The wrapper holds only `@app` (shareable), so the
    # wrapper itself is `Ractor.make_shareable`.
    #
    # Usage in a kino `config_ractor.ru`:
    #   app = RactorRailsShim.make_app_shareable!(Rails.application)
    #   app = RactorRailsShim.worker_ar_init(app)
    #   run app
    class ArWorkerInitWrapper
      def initialize(app)
        @app = app
      end

      def call(env)
        RactorRailsShim.init_worker_ar_connections!
        @app.call(env)
      end
    end

    # Wrap `app` so every worker Ractor initializes its ActiveRecord
    # connections on first request. Returns a shareable wrapper.
    def worker_ar_init(app)
      ArWorkerInitWrapper.new(app)
    end

    # Patch ActiveRecord::QueryLogs#tag_content. It reads the `@handlers` and
    # `@formatter` class ivars (populated from config.active_record.query_log_tags
    # during boot) on every SQL statement, so a worker Ractor raises
    # Ractor::IsolationError. `cached_comment` is a thread_mattr_accessor (already
    # Ractor-safe), so only the handlers/formatter need handling. Capture a
    # shareable snapshot in main (snapshot_query_logs!, post-boot) and have
    # workers build the comment from it — query-log tags then work in workers
    # exactly as in dev's main Ractor.
    def _install_activerecord_query_logs_patch
      return if @query_logs_patched
      @query_logs_patched = true
      _register_patch :query_logs, "8.1"
      return unless defined?(::ActiveRecord::QueryLogs)
      ql = ::ActiveRecord::QueryLogs
      # tag_content is defined as a SINGLETON method on ActiveRecord::QueryLogs
      # (not an instance method), so alias the singleton method (not an
      # instance one) and fall back to it for the main Ractor / when the
      # snapshot is unavailable.
      ql.singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        alias_method :__ractors_original_tag_content, :tag_content
        def tag_content(connection)
          return __ractors_original_tag_content(connection) if Ractor.main?
          snap = ::RactorRailsShim::QUERY_LOGS_SNAPSHOT
          return __ractors_original_tag_content(connection) unless snap
          format = snap[:format]
          formatter = case format
            when :sqlcommenter then ::ActiveRecord::QueryLogs::SQLCommenter
            else ::ActiveRecord::QueryLogs::LegacyFormatter
          end
          return nil unless formatter
          context = ActiveSupport::ExecutionContext.to_h
          context[:connection] ||= connection
          pairs = snap[:handlers].filter_map do |(key, kind, data)|
            val = case kind
              when :get_key then context[key]
              when :identity then data
              else nil
            end
            formatter.format(key, val) unless val.nil?
          end
          formatter.join(pairs)
        end
      RUBY
    end

    # Capture the QueryLogs handlers/formatter as a shareable snapshot for
    # workers (called post-boot, main Ractor, in prepare_for_ractors!).
    #
    # We deliberately do NOT use Ractor.make_shareable on the raw `@handlers`
    # objects: a handler may be a ZeroArityHandler wrapping a Proc, a raw
    # lambda/Proc tag, or an IdentityHandler whose value is unshareable — all of
    # which make_shareable raises on, which (the original rescue swallowed) left
    # QUERY_LOGS_SNAPSHOT unset and every worker falling through to the original
    # tag_content -> @handlers read -> Ractor::IsolationError. Instead we build a
    # fresh, guaranteed-shareable structure:
    #   { format: :legacy|:sqlcommenter,
    #     handlers: [[key, :get_key, nil] | [key, :identity, value], ...] }
    # Only GetKeyHandler (context key lookup) and IdentityHandler (constant
    # value, when that value itself is shareable) are captured. Proc/lambda
    # handlers can't be expressed cross-Ractor and are dropped in workers (tags
    # that depend on per-request Procs simply don't appear in worker query
    # comments — acceptable; the main Ractor still logs them).
    def snapshot_query_logs!
      return unless defined?(::ActiveRecord::QueryLogs)
      return if RactorRailsShim.const_defined?(:QUERY_LOGS_SNAPSHOT)
      return unless Ractor.main?
      begin
        ql = ::ActiveRecord::QueryLogs
        format = ql.tags_formatter
        format = :legacy if format == false || format.nil?
        raw_handlers = ql.instance_variable_get(:@handlers) || []
        entries = []
        raw_handlers.each do |key, handler|
          if handler.is_a?(::ActiveRecord::QueryLogs::GetKeyHandler)
            entries << [key, :get_key, nil]
          elsif handler.is_a?(::ActiveRecord::QueryLogs::IdentityHandler)
            value = handler.instance_variable_get(:@value)
            next unless Ractor.shareable?(value)
            entries << [key, :identity, value]
          else
            # ZeroArityHandler (wraps a Proc) or a raw Proc/lambda tag:
            # intrinsically unshareable / depends on a closure; skip in workers.
            next
          end
        end
        snap = { format: format, handlers: entries.freeze }.freeze
        Ractor.make_shareable(snap)
        RactorRailsShim.const_set(:QUERY_LOGS_SNAPSHOT, snap)
      rescue StandardError
        nil
      end
    end

    # Patch ActiveRecord::Migrator.migrations_paths (a singleton attr_accessor
    # reading the `@migrations_paths` class ivar) and
    # ActiveRecord::Migration::CheckPending (the dev pending-migration
    # middleware) to be Ractor-safe. In dev, CheckPending runs on every request
    # and reads Migrator.migrations_paths + mutates its own `@watcher` /
    # `@needs_check` ivars on the (frozen, shared) middleware instance. Route
    # the class ivar and the instance ivars through IsolatedExecutionState so
    # each worker reads the main Ractor's migrations paths and builds its own
    # watcher. This keeps the dev pending-migration guard working under kino
    # :ractor instead of stripping the middleware.
    def _install_activerecord_migration_patch
      return if @activerecord_migration_patched
      @activerecord_migration_patched = true
      _register_patch :activerecord_migration, "8.1"
      return unless defined?(::ActiveRecord::Migrator)

      mig = ::ActiveRecord::Migrator
      mp_key = :ractor_rails_shim_migrator_migrations_paths
      mp_key_str = mp_key.inspect
      mig.singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def migrations_paths
          v = RactorRailsShim.storage[#{mp_key_str}]
          return v unless v.nil?
          return nil if RactorRailsShim.storage.key?(#{mp_key_str})
          if Ractor.main? && instance_variable_defined?(:@migrations_paths)
            v = @migrations_paths
            RactorRailsShim.storage[#{mp_key_str}] = v
            v
          else
            ["db/migrate"].freeze
          end
        end
        def migrations_paths=(val)
          RactorRailsShim.storage[#{mp_key_str}] = val
          @migrations_paths = val if Ractor.main?
          val
        end
      RUBY

      return unless defined?(::ActiveRecord::Migration::CheckPending)
      cp = ::ActiveRecord::Migration::CheckPending
      w_key = :ractor_rails_shim_check_pending_watcher
      nc_key = :ractor_rails_shim_check_pending_needs_check
      w_key_str = w_key.inspect
      nc_key_str = nc_key.inspect
      cp.class_eval <<-RUBY, __FILE__, __LINE__ + 1
        def call(env)
          @mutex.synchronize do
            watcher = RactorRailsShim.storage[#{w_key_str}]
            if watcher.nil?
              watcher = RactorRailsShim.storage[#{w_key_str}] = build_watcher do
                RactorRailsShim.storage[#{nc_key_str}] = true
                ::ActiveRecord::Migration.check_pending_migrations
                RactorRailsShim.storage[#{nc_key_str}] = false
              end
            end
            needs_check = RactorRailsShim.storage[#{nc_key_str}]
            needs_check = true if needs_check.nil?
            if needs_check
              watcher.execute
            else
              watcher.execute_if_updated
            end
          end
          @app.call(env)
        end
      RUBY
    end

    # In the shared :ractor graph, ActiveRecord model classes can end up with a
    # nil `__callbacks` (the class_attribute value can't be made shareable when
    # it holds unshareable callback Procs, so the shim's shareable fallback
    # returns nil). `has_transactional_callbacks?` calls the generated
    # `_rollback_callbacks` / `_commit_callbacks` / `_before_commit_callbacks`
    # readers, which do `__callbacks[:kind]` directly — bypassing the
    # `run_callbacks_with_nil_safe` guard. With a nil `__callbacks` that raises
    # `NoMethodError: undefined method '[]' for nil`, breaking every
    # `save` / `update` / `destroy` (they run inside a transaction). Guard it:
    # a nil / empty callback table means no transactional callbacks.
    def _install_activerecord_transaction_callbacks_patch
      return if @activerecord_transaction_callbacks_patched
      @activerecord_transaction_callbacks_patched = true
      _register_patch :activerecord_transaction_callbacks, "8.1"
      return unless defined?(::ActiveRecord::Base)
      ar = ::ActiveRecord::Base
      ar.class_eval <<-RUBY, __FILE__, __LINE__ + 1
        def has_transactional_callbacks?
          cb = __callbacks
          return false unless cb
          !((cb[:rollback] || []).empty?) ||
            !((cb[:commit] || []).empty?) ||
            !((cb[:before_commit] || []).empty?)
        end
      RUBY
    end

    # Patch ActiveRecord::Scoping::Named::ClassMethods#scope to use string
    # eval instead of define_method. Rails defines scope methods via
    # `singleton_class.define_method(name) { |*args| scope = all._exec_scope(*args, &body) ... }`.
    # The block captures the `body` Proc (a lambda like `-> { order(created_at: :desc) }`)
    # from the main Ractor. Calling that block from a worker Ractor raises
    # "defined with an un-shareable Proc in a different Ractor".
    #
    # The body lambda itself CANNOT be made shareable (Proc#self is always
    # the enclosing scope, which is the main Ractor). Fix: use
    # Proc#source_location to read the body's source code at prepare time
    # (main Ractor), store it in a shareable constant, and define the scope
    # method via string eval that eval's the stored source code. This avoids
    # ever calling the original lambda from a worker.
    def _install_activerecord_scope_patch
      return if @ar_scope_patched
      @ar_scope_patched = true
      _register_patch :activerecord_scope, "8.1"
      # The scope macro MUST be patched BEFORE the app's models are eager
      # loaded, so `scope :recent, -> { ... }` defines a worker-safe method
      # (string-eval'd body) instead of Rails' un-shareable define_method.
      # Apply now if AR is already loaded, otherwise hook active_record's load
      # (which fires during framework boot, before eager-load). Never force a
      # `require "active_record"` here — that would double-load AR under
      # `bundle exec` and re-define constants after the shim froze them.
      if defined?(::ActiveRecord::Scoping::Named::ClassMethods)
        _apply_activerecord_scope_patch
      else
        ActiveSupport.on_load(:active_record) do
          RactorRailsShim.__send__(:_apply_activerecord_scope_patch)
        end
      end
    end

    def _apply_activerecord_scope_patch
      return unless defined?(::ActiveRecord::Scoping::Named::ClassMethods)

      # Shareable (frozen) registry of scope source code:
      # { "Model" => { :recent => [body_source, [params]] } }. It MUST be a
      # frozen shareable object so worker Ractors can read it from the shared
      # app graph. But scopes register their bodies during boot eager-load
      # (after this patch installs, before the graph freezes), so each write
      # rebuilds the frozen Hash atomically via const_set. Cost is negligible
      # (scopes are defined only at boot).
      unless RactorRailsShim.const_defined?(:SCOPE_SOURCE_CODES)
        RactorRailsShim.const_set(:SCOPE_SOURCE_CODES, Ractor.make_shareable({}))
      end

      mod = ::ActiveRecord::Scoping::Named::ClassMethods
      mod.module_eval do
        alias_method :_rrs_orig_scope, :scope unless method_defined?(:_rrs_orig_scope)

        def scope(name, body = nil, &block)
          unless body.respond_to?(:call)
            raise ArgumentError, "The scope body needs to be callable."
          end

          if dangerous_class_method?(name)
            raise ArgumentError, "You tried to define a scope named \"#{name}\" " \
              "on the model \"#{self.name}\", but Active Record already defined " \
              "a class method with the same name."
          end

          if method_defined_within?(name, ::ActiveRecord::Relation)
            raise ArgumentError, "You tried to define a scope named \"#{name}\" " \
              "on the model \"#{self.name}\", but ActiveRecord::Relation already defined " \
              "an instance method with the same name."
          end

          extension = Module.new(&block) if block

          # Extract the body's source code from the lambda's source_location
          # so workers can eval it without calling the original Proc.
          model_name_str = self.name.to_s
          scope_name_str = name.to_s
          body_source = nil
          if body.respond_to?(:source_location)
            file, line = body.source_location
            if file && line
              begin
                source_lines = File.readlines(file)
                raw_line = source_lines[line - 1]&.strip
                if raw_line
                  # Extract the body from patterns like:
                  #   scope :name, -> { ... }
                  #   scope(:name, -> { ... })
                  #   scope :name, ->(arg) { ... }
                  if raw_line =~ /->\s*(?:\([^)]*\))?\s*\{/
                    # Find the matching closing brace
                    full_source = raw_line
                    depth = 0
                    start_idx = raw_line.index("{")
                    if start_idx
                      (start_idx...raw_line.length).each do |i|
                        case raw_line[i]
                        when "{"
                          depth += 1
                        when "}"
                          depth -= 1
                          if depth == 0
                            full_source = raw_line[start_idx + 1..i - 1].strip
                            break
                          end
                        end
                      end
                    end
                    # Also check multi-line if the brace wasn't closed
                    if depth > 0
                      ((line)..(line + 10)).each do |ln|
                        next_line = source_lines[ln]&.strip
                        next unless next_line
                        full_source += " " + next_line
                        next_line.each_char do |c|
                          depth += 1 if c == "{"
                          depth -= 1 if c == "}"
                          if depth == 0
                            # Trim the extra }
                            full_source = full_source[0..-(next_line.length - next_line.rindex("}") + 2)]
                            break
                          end
                        end
                        break if depth <= 0
                      end
                    end
                    body_source = full_source
                  end
                end
              rescue StandardError
                nil
              end
            end
          end

          # Store the body_source + parameter names in the shareable constant
          # (cross-Ractor). Parameter names let workers bind the call's args
          # (scopes like `by_title(q)`) without ever referencing the caller's
          # main-Ractor locals.
          if body_source
            param_names = if body.respond_to?(:parameters)
                            body.parameters.map { |p| p[1] }.compact
                          else
                            []
                          end
            cur = RactorRailsShim.const_defined?(:SCOPE_SOURCE_CODES) ? RactorRailsShim::SCOPE_SOURCE_CODES : {}
            cur = cur.dup
            cur[model_name_str] ||= {}
            cur[model_name_str] = cur[model_name_str].dup
            cur[model_name_str][scope_name_str.to_sym] = [body_source, param_names]
            # Reassigning a constant that already exists warns ("already
            # initialized constant"); drop the old binding first so each scope
            # registration stays silent.
            RactorRailsShim.send(:remove_const, :SCOPE_SOURCE_CODES) if RactorRailsShim.const_defined?(:SCOPE_SOURCE_CODES, false)
            RactorRailsShim.const_set(:SCOPE_SOURCE_CODES, Ractor.make_shareable(cur))
          end

          # Also store extension if present. Scope extensions are Modules, which
          # are not shareable across Ractors, so keep them in per-Ractor storage
          # (available in the Ractor that defined the scope; workers without the
          # extension simply skip it — acceptable for the common no-extension case).
          if extension
            Ractor.current[:"rrs_scope_ext_#{model_name_str}_#{scope_name_str}"] = extension
          end

          # Define via string eval (compiled def, not define_method block).
          #
          # CRITICAL: the scope body must be evaluated from a STRING, not a
          # block. A literal block `{ order(...) }` written here is compiled in
          # the main Ractor (where this method is defined) and calling it from a
          # worker raises "defined with an un-shareable Proc in a different
          # Ractor". `instance_eval(string)` compiles the string at CALL time, in
          # the worker Ractor, so it is shareable. Scope args are bridged onto a
          # transient ivar on the relation (`@_rrs_scope_args`) so the body can
          # read them with `self` bound to the relation.
          if body_source
            singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
              def #{name}(*args)
                store = RactorRailsShim::SCOPE_SOURCE_CODES[self.name]
                info = store && store[:"#{scope_name_str}"]
                ext_key = :"rrs_scope_ext_\#{self.name}_#{scope_name_str}"
                ext = Ractor.current[ext_key]
                return super(*args) unless info
                body_source, param_names = info
                bind = param_names.each_with_index.map { |n, i| "\#{n} = @_rrs_scope_args[\#{i}]" }.join("; ")
                code = bind.empty? ? body_source : "\#{bind}; \#{body_source}"
                # Capture `all` once: it is a method call that returns a fresh
                # relation each time, so setting the args ivar on one instance
                # and evaluating `code` on another would leave @_rrs_scope_args
                # nil on the eval target (raising "undefined method '[]' for
                # nil"). Use the same relation for both.
                rel = all
                rel.instance_variable_set(:@_rrs_scope_args, args)
                scope = rel.instance_eval(code)
                scope = scope.extending(ext) if ext
                scope
              end
            RUBY
          else
            # Fallback: use the original define_method approach (works in main only).
            if body.respond_to?(:to_proc)
              singleton_class.define_method(name) do |*args|
                scope = all._exec_scope(*args, &body)
                scope = scope.extending(extension) if extension
                scope
              end
            else
              singleton_class.define_method(name) do |*args|
                scope = body.call(*args) || all
                scope = scope.extending(extension) if extension
                scope
              end
            end
            singleton_class.send(:ruby2_keywords, name)
          end

          generate_relation_method(name)
        end
      end
    end

    # Patch ActiveRecord::AutosaveAssociation's proc-backed association
    # callbacks. Rails generates `autosave_associated_records_for_<assoc>` /
    # `validate_associated_records_for_<assoc>` via `define_non_cyclic_method`
    # -> `define_method(&block)` — the method body is a Proc compiled in the
    # main Ractor. Calling it from a worker raises "defined with an
    # un-shareable Proc in a different Ractor", which the shim's
    # SymbolicTransport callback replay treats as skip-and-continue — so
    # nested attributes (built children stay in the association target but
    # are never INSERTed) and `validate:` associations silently no-op in
    # workers (observed: Post.create!(comments_attributes:) persisted the
    # post but zero comments, counter_cache stayed 0).
    #
    # Fix (prepare-time): make the UNFROZEN data constants inside the
    # ActiveModel::Validations tree Ractor-shareable (deep-freeze them).
    # Validators read these from worker Ractors — e.g. LengthValidator's
    # `RESERVED_OPTIONS.each` in validate_each raises
    # `Ractor::IsolationError: can not access non-shareable objects in
    # constant …LengthValidator::RESERVED_OPTIONS by non-main` the first
    # time a length validation runs in a worker. Upstream never mutates
    # these constants, so freezing is safe. Only Array/Hash/String/Set
    # constants are touched; classes/modules are natively shareable.
    # Runs from _prewarm_activerecord_memoizations! (before the graph
    # freeze — a constant the main graph froze is already shareable; this
    # covers constants the shim's own traversal does not reach).
    def _share_activemodel_validation_constants!
      return unless defined?(::ActiveModel)
      owners = [::ActiveModel]
      owners << ::ActiveModel::Validations if defined?(::ActiveModel::Validations)
      owners << ::ActiveRecord::Validations if defined?(::ActiveRecord::Validations)
      owners.each do |namespace|
        (namespace.constants rescue []).each do |c|
          owner = namespace.const_get(c) rescue next
          next unless owner.is_a?(::Class) || owner.is_a?(::Module)
          (owner.constants rescue []).each do |nested|
          value = owner.const_get(nested) rescue next
          next if Ractor.shareable?(value)
          next unless value.is_a?(::Array) || value.is_a?(::Hash) ||
                      value.is_a?(::String) || value.is_a?(::Set)
          begin
            Ractor.make_shareable(value)
          rescue StandardError, Ractor::Error
            nil
          end
        end
      end
      end
    end

    # Fix (prepare-time, like _redefine_engine_railtie_singletons!): walk
    # every AR model's associations and re-define both method families as
    # REAL `def`s whose body looks the reflection up from the class itself
    # (self.class.reflect_on_association — a frozen, worker-readable Hash
    # lookup), with define_non_cyclic_method's cyclic guard inlined. Only
    # methods whose source is Rails' autosave_association.rb are replaced;
    # an app's own override wins (mirrors upstream's method_defined? guard).
    # Runs AFTER eager load from _prewarm_activerecord_memoizations! (before
    # the graph freeze, so class_eval still works and workers clone the
    # re-defined method table).
    def _redefine_ar_autosave_methods!
      return unless defined?(::ActiveRecord::Base)

      classes = ([::ActiveRecord::Base] + (::ActiveRecord::Base.descendants rescue [])).compact
      classes.each do |klass|
        next unless klass.name
        begin
          refls = (klass.reflect_on_all_associations rescue nil)
          (refls || []).each do |refl|
            name = refl.name.to_s
            refl_lookup = "self.class.reflect_on_association(#{name.inspect})"

            # NOTE: association scopes' where-values for worker-built records
            # are handled by _install_ar_association_scope_attrs_patch (the
            # build path saves has_ones immediately via replace(), before any
            # autosave hook could run).
            save_method = :"autosave_associated_records_for_#{name}"
            if klass.method_defined?(save_method) && _rrs_rails_autosave_source?(klass, save_method)
              body_call =
                if refl.collection?
                  "save_collection_association(#{refl_lookup})"
                elsif refl.has_one?
                  "save_has_one_association(#{refl_lookup})"
                else
                  "throw(:abort) if save_belongs_to_association(#{refl_lookup}) == false"
                end
              klass.class_eval <<~RUBY, __FILE__, __LINE__ + 1
                def #{save_method}
                  result = true
                  @_already_called ||= {}
                  unless @_already_called[:#{name}]
                    begin
                      @_already_called[:#{name}] = true
                      result = #{body_call}
                    ensure
                      @_already_called[:#{name}] = false
                    end
                  end
                  result
                end
              RUBY
            end

            validation_method = :"validate_associated_records_for_#{name}"
            if klass.method_defined?(validation_method) && _rrs_rails_autosave_source?(klass, validation_method)
              val_method =
                if refl.collection?
                  :validate_collection_association
                elsif refl.has_one?
                  :validate_has_one_association
                else
                  :validate_belongs_to_association
                end
              klass.class_eval <<~RUBY, __FILE__, __LINE__ + 1
                def #{validation_method}
                  result = true
                  @_already_called ||= {}
                  unless @_already_called[:#{name}]
                    begin
                      @_already_called[:#{name}] = true
                      result = send(:#{val_method}, #{refl_lookup})
                    ensure
                      @_already_called[:#{name}] = false
                    end
                  end
                  result
                end
              RUBY
            end
          end
        rescue StandardError => e
          warn "ractor-rails-shim: autosave method redefinition failed for #{klass.name} " \
               "(#{e.class}: #{e.message[0, 160]})"
        end
      end
      nil
    end

    # True when the method was generated by Rails' define_non_cyclic_method
    # (its source_location points at autosave_association.rb). Ruby 4 returns
    # an Array there — normalize first.
    def _rrs_rails_autosave_source?(klass, method_name)
      src = (klass.instance_method(method_name).source_location rescue nil)
      srcs = src.is_a?(Array) ? src : [src].compact
      srcs.any? { |s| s.is_a?(String) && s.end_with?("autosave_association.rb") }
    end

    # Fix (prepare-time, like _redefine_ar_autosave_methods!): ActiveRecord
    # enums generate their predicate/bang methods (`moderated?`, `moderated!`)
    # via `define_method` with Procs compiled inside `_enum_methods_module` —
    # a Module whose method-table Procs the shim's proc-replacement traversal
    # cannot reach (it walks ivars, not included modules' method tables).
    # Workers calling those methods raise "defined with an un-shareable Proc
    # in a different Ractor" (observed: every enum bang/predicate in a
    # worker Ractor). The class-level `#{name.pluralize}` values reader
    # (e.g. `Post.states`) and the per-value scopes (`Post.moderated`,
    # `Post.not_moderated`) have the same problem (scope bodies are Procs
    # capturing `name`/`value` locals; workers replay them with a lost
    # binding and die on `NameError: undefined local variable or method
    # 'value'`).
    #
    # Re-define all four families as REAL `def`s (string-eval'd, mirroring
    # the engine-singleton pattern): predicates read the attribute via the
    # generated `#{name}_for_database` reader and compare against the baked
    # value; bangs write through `update!`; scopes build plain
    # `all.where(...)` relations; the pluralized values reader returns the
    # frozen `defined_enums` hash, const-backed so the def needs no class
    # attribute read. Overriding is safe: Rails' `detect_enum_conflict!`
    # raises at `enum` declaration time when a user method already occupies
    # any of these names, so every method we replace belongs to the enum.
    # Runs AFTER eager load from _prewarm_activerecord_memoizations! (before
    # the graph freeze, so class_eval still works and workers clone the
    # re-defined method table).
    def _redefine_ar_enum_methods!
      return unless defined?(::ActiveRecord::Base) && ::ActiveRecord::Base.method_defined?(:update!)
      return if @ar_enum_methods_redefined
      @ar_enum_methods_redefined = true
      _register_patch :ar_enum_methods, "8.1"

      classes = ((::ActiveRecord::Base.descendants rescue []) + [::ActiveRecord::Base]).compact
      classes.each do |klass|
        next unless klass.name
        begin
          enums = (klass.defined_enums rescue nil)
          next unless enums.is_a?(::Hash) && !enums.empty?
          enum_mod = (klass.send(:_enum_methods_module) rescue nil)
          next unless enum_mod.is_a?(::Module)

          # Predicate + bang methods: enumerate the enum methods module and
          # map each `?`/`!` method back to its (attribute, value) pair by
          # matching the stripped base name against the declared labels.
          # Prefix/suffix/alias value-method variants (non-Word labels)
          # cannot be mapped reliably here and are left as-is (documented
          # residual: such variants stay worker-unavailable).
          enum_mod.instance_methods(false).each do |mname|
            base = mname.to_s
            if base.end_with?("?")
              kind = :predicate
              base = base[0..-2]
            elsif base.end_with?("!")
              kind = :bang
              base = base[0..-2]
            else
              next
            end
            found = nil
            enums.each do |enum_name, values|
              if values.key?(base)
                found = [enum_name, values[base]]
                break
              end
            end
            next unless found
            enum_name, value = found
            case kind
            when :predicate
              klass.class_eval(<<~RUBY, __FILE__, __LINE__ + 1)
                def #{mname}
                  public_send(:#{enum_name}_for_database) == #{value.inspect}
                end
              RUBY
            when :bang
              klass.class_eval(<<~RUBY, __FILE__, __LINE__ + 1)
                def #{mname}
                  update!(#{enum_name.inspect} => #{value.inspect})
                end
              RUBY
            end
          end

          # Scopes + the pluralized values reader: enum scopes are named
          # exactly after the value labels (positive) and `not_#{label}`
          # (negative, when `scopes:` is enabled — the default). The values
          # reader is `#{enum_name}.pluralize`.
          enums.each do |enum_name, values|
            values.each_key do |label|
              label = label.to_s
              {"" => "where", "not_" => "where.not"}.each do |pre, query|
                sname = "#{pre}#{label}"
                next unless klass.respond_to?(sname, true)
                klass.singleton_class.class_eval(<<~RUBY, __FILE__, __LINE__ + 1)
                  def #{sname}
                    all.#{query}(#{enum_name.inspect} => #{values[label].inspect})
                  end
                RUBY
              end
            end
            plural = enum_name.to_s.pluralize
            if klass.respond_to?(plural, true)
              const_name = :"RRS_ENUM_VALUES_#{enum_name.to_s.upcase}"
              klass.const_set(const_name, values) unless klass.const_defined?(const_name, false)
              klass.singleton_class.class_eval(<<~RUBY, __FILE__, __LINE__ + 1)
                def #{plural}
                  #{klass.name}::#{const_name}
                end
              RUBY
            end
          end
        rescue StandardError => e
          warn "ractor-rails-shim: enum method redefinition failed for #{klass.name} " \
               "(#{e.class}: #{e.message[0, 160]})"
        end
      end
      nil
    end

    # Fix (prepare-time): ActiveModel::AttributeRegistration queues attribute
    # work as PendingType/PendingDefault/PendingDecorator Structs in the
    # class ivar `@pending_attribute_modifications`. Enum declarations add a
    # PendingDecorator whose `decorator` member is a Proc compiled inside
    # `ActiveRecord::Enum#enum` (it builds the EnumType from captured
    # locals). Struct members are NOT instance variables, so the shim's
    # proc-replacement traversal never reaches the Proc — the pending
    # Array ends up frozen-but-unshareable, every worker read falls back to
    # empty, and the worker-side attribute rebuild applies ONLY the
    # schema-column decorators. Result in workers: the enum attribute type
    # registration is lost (`p.state` casts to raw 0 instead of "draft",
    # `p.state = :moderated` casts to nil — silent data corruption).
    #
    # Make every Proc member of every pending Struct shareable in place
    # (self is the model class — shareable — and the captured locals are the
    # enum name/labels hash/flags, all shareable); undecoratable Procs get a
    # no-op (the decoration is then skipped, preserving the type as-is).
    # Then freeze the Array. Workers clone the shareable pending list and
    # rebuild `@default_attributes` / `@attribute_types` locally, replaying
    # the EnumType registration themselves (a fresh EnumType is constructed
    # per Ractor from the frozen decorator closure — safe and correct).
    # Runs AFTER eager load from _prewarm_activerecord_memoizations! (before
    # the graph freeze).
    def _share_ar_pending_attribute_modifications!
      return unless defined?(::ActiveRecord::Base)
      return if @ar_pending_attribute_modifications_shared
      @ar_pending_attribute_modifications_shared = true
      _register_patch :ar_pending_attribute_modifications, "8.1"

      noop_builder = nil
      classes = ((::ActiveRecord::Base.descendants rescue []) + [::ActiveRecord::Base]).compact
      classes.each do |klass|
        next unless klass.name
        begin
          pending = klass.instance_variable_get(:@pending_attribute_modifications)
          next unless pending.is_a?(::Array)

          # NOTE: an earlier prepare pass (_share_model_classes! walks class
          # ivars and calls Ractor.make_shareable on them) can PARTIALLY
          # FREEZE the pending entries — a failed make_shareable freezes
          # everything it traversed before failing, and the Struct members
          # it failed on (unshareable Procs invisible to the ivar walk) stay
          # frozen-unshareable. Frozen Struct members cannot be written, so
          # entries that did not come out shareable are REBUILT as fresh
          # Struct instances (same class, same members, Procs made shareable
          # or swapped for no-ops) and the Array is replaced wholesale while
          # the class itself is still mutable.
          rebuilt = false
          new_pending = pending.map do |entry|
            next entry if Ractor.shareable?(entry) rescue entry
            if entry.is_a?(::Struct)
              vals = entry.members.map do |mem|
                val = (entry[mem] rescue next nil)
                next val if val.nil? || Ractor.shareable?(val)
                next val unless val.is_a?(::Proc)
                begin
                  Ractor.make_shareable(val)
                rescue StandardError, Ractor::Error
                  # RETRY PASS: a decoration Proc whose captured binding LOCALS
                  # are simple unfrozen value objects (e.g. the
                  # `serialize :arguments, coder: JSON` decorator captures an
                  # unfrozen `ActiveRecord::Coders::JSON` instance) fails
                  # make_shareable with "it can refer unshareable object
                  # <X> from variable '<name>'". Freeze each local VALUE in
                  # place (main Ractor, pre-freeze), then retry. If the retry
                  # succeeds the decorator replays in workers.
                  shared_after_retry = false
                  begin
                    bnd = val.binding
                    bnd.local_variables.each do |lv|
                      lval = (bnd.local_variable_get(lv) rescue next)
                      next if lval.nil? || (Ractor.shareable?(lval) rescue true)
                      begin
                        Ractor.make_shareable(lval)
                      rescue StandardError, Ractor::Error
                        nil
                      end
                    end
                    shared_after_retry = (Ractor.make_shareable(val) rescue false) ? true : false
                  rescue StandardError, Ractor::Error
                    shared_after_retry = false
                  end
                  val if shared_after_retry
                end ||
                  begin
                    # Ruby refuses make_shareable on the enum decoration Proc
                    # ("the outer variable 'validate' may be reassigned" in
                    # ActiveRecord::Enum#enum). Reconstruct the decoration as a
                    # shareable callable: read the closure's captured locals
                    # via Proc#binding (main Ractor, pre-freeze) and bake them
                    # into a shareable decorator callable that rebuilds the
                    # fresh type per apply.
                    replacement = nil
                    loc = (val.source_location rescue nil)
                    srcs = loc.is_a?(::Array) ? loc : [loc]
                    if srcs.any? { |s| s.is_a?(::String) && s.end_with?("enum.rb") } && defined?(::ActiveRecord::Enum::EnumType)
                      begin
                        bnd = val.binding
                        enum_name = bnd.local_variable_get(:name)
                        enum_values = bnd.local_variable_get(:enum_values)
                        validate = bnd.local_variable_get(:validate)
                        replacement = RactorRailsShim.singleton_class.const_get(:EnumTypeDecorator)
                                             .new(enum_name, enum_values, validate)
                        Ractor.make_shareable(replacement)
                      rescue StandardError, Ractor::Error
                        replacement = nil
                      end
                    end
                    # `serialize :attr, coder: ...` decorations (the
                    # serialization.rb closure over `column_serializer` —
                    # unshareable because the upstream `coder ||=` reassignment
                    # taints the proc): rebuild as a shareable callable. The
                    # binding-locals freeze pass above already froze
                    # `column_serializer` (a Coders::JSON instance) in place.
                    #
                    # SCOPE GUARD: only VALUE-OBJECT coders (the
                    # ActiveRecord::Coders::* instances — mechanical
                    # JSON/YAML round-trips). Coder CLASSES (e.g.
                    # ActionText::Content for rich-text bodies) carry domain
                    # semantics whose load path needs Nokogiri — a permanent
                    # worker wall — so those keep the pre-fix behavior (the
                    # decoration no-ops; the attribute keeps its column type
                    # and the body round-trips as stored HTML, which is what
                    # the app's rich-text probes are built on — row 120).
                    if replacement.nil? && srcs.any? { |s| s.is_a?(::String) && s.end_with?("serialization.rb") } &&
                       defined?(::ActiveRecord::Type::Serialized)
                      begin
                        bnd = val.binding
                        column_serializer = bnd.local_variable_get(:column_serializer)
                        comparable = bnd.local_variable_get(:comparable)
                        unless column_serializer.is_a?(::Class) || column_serializer.is_a?(::Module)
                          Ractor.make_shareable(column_serializer) rescue nil
                          replacement = RactorRailsShim.singleton_class.const_get(:SerializedTypeDecorator)
                                               .new(column_serializer, comparable)
                          Ractor.make_shareable(replacement)
                        end
                      rescue StandardError, Ractor::Error
                        replacement = nil
                      end
                    end
                    replacement ||
                      begin
                        # Undecorable Proc (binding self or locals unshareable):
                        # swap a no-op in so the Struct stays shareable.
                        # PendingDecorator#apply_to ignores a nil return, so the
                        # attribute keeps its prior type.
                        noop_builder ||= RactorRailsShim.singleton_class.const_get(:NoOpProc)
                        noop_builder.new
                      end
                  end
              end
              e2 = entry.class.new(*vals)
              begin
                Ractor.make_shareable(e2)
              rescue StandardError, Ractor::Error
                nil
              end
              rebuilt = true
              e2
            else
              entry
            end
          end
          if rebuilt
            klass.instance_variable_set(:@pending_attribute_modifications, new_pending)
            pending = new_pending
          end
          begin
            Ractor.make_shareable(pending)
          rescue StandardError, Ractor::Error
            nil
          end
        rescue StandardError => e
          warn "ractor-rails-shim: pending attribute modification sharing failed for " \
               "#{klass.name} (#{e.class}: #{e.message[0, 160]})"
        end
      end
      nil
    end

    # Association scopes (`has_one :x, -> { where(name: name) }, ...`) are
    # main-compiled Procs: workers can neither call them (their `self` is the
    # not-yet-shareable model class at replacement time, so they become
    # NoOpProcs) nor re-derive them. Rails normally applies a scope's
    # where-values to records BUILT through the association
    # (Association#initialize_attributes <- scope_for_create). Observed
    # without the fix: worker-built ActionText::RichText rows INSERTed with a
    # NULL `name` and hit a NotNullViolation — and the INSERT happens inside
    # HasOneAssociation#replace (owner persisted → immediate save), so no
    # autosave-time hook can fix it.
    #
    # Fix: redefine initialize_attributes with the upstream body plus a
    # re-application of the values captured by _share_model_classes! into
    # @rrs_assoc_scope_attrs (a frozen, shareable module ivar — readable from
    # workers). Idempotent in main, where scope_for_create already carries
    # the values (attribute_present? skips them).
    def _install_ar_association_scope_attrs_patch
      return if @ar_assoc_scope_attrs_patched
      @ar_assoc_scope_attrs_patched = true
      _register_patch :ar_association_scope_attrs, "8.1"
      return unless defined?(::ActiveRecord::Associations::Association)

      ::ActiveRecord::Associations::Association.class_eval <<~'RUBY', __FILE__, __LINE__ + 1
        def initialize_attributes(record, except_from_scope_attributes = nil) # :nodoc:
          except_from_scope_attributes ||= {}
          skip_assign = [reflection.foreign_key, reflection.type].compact
          assigned_keys = record.changed_attribute_names_to_save
          assigned_keys += except_from_scope_attributes.keys.map(&:to_s)
          attributes = scope_for_create.except!(*(assigned_keys - skip_assign))
          record.send(:_assign_attributes, attributes) if attributes.any?
          if record.respond_to?(:new_record?) && record.new_record?
            table = RactorRailsShim.instance_variable_get(:@rrs_assoc_scope_attrs)
            baked = table && table[reflection.active_record.name]
            baked = baked && baked[reflection.name.to_s]
            if baked
              baked.each do |k, v|
                record[k] = v unless record.attribute_present?(k)
              end
            end
          end
          set_inverse_instance(record)
        end
      RUBY
      ::ActiveRecord::Associations::Association.send(:private, :initialize_attributes)
    end
  end
end
