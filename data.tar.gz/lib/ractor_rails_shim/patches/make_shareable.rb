# frozen_string_literal: true

# make_app_shareable! entry point + the SHAREABLE_CONSTANTS /
# SHAREABLE_CLASS_IVARS registrations for Devise / ActiveSupport / Warden.
#
# The graph-traversal, callable/lock replacement, shareable-fallback, and
# logger-neutralization machinery that used to live here was extracted to
# role objects (ShareabilityTraversal, FallbackBuilder, LoggerIONeutralizer,
# CallbackCapture, ActionDispatchStrategy, Freezers::*)
# in Issues #13/#22. Issue #31 deletes the facade delegations that forwarded
# to those role objects; the role objects are now called directly. This file
# keeps only the genuine public entry (`make_app_shareable!`) and the two
# constant registrations that must run at load time (before Devise /
# ActiveSupport / Warden are loaded).

module RactorRailsShim
  class << self
    # Devise defines several mutable module-level constants (Array/Hashes
    # populated at load time: mappings, strategies, url helpers, no_input
    # strategies). Worker Ractors read them (e.g. Devise::NO_INPUT in
    # mapping.rb), so they must be deep-frozen + made shareable before the
    # app graph is frozen. Added here; make_constant_shareable! resolves each
    # lazily once Devise is loaded.
    SHAREABLE_CONSTANTS.concat([
      "Devise::ALL",
      "Devise::CONTROLLERS",
      "Devise::ROUTES",
      "Devise::STRATEGIES",
      "Devise::URL_HELPERS",
      "Devise::NO_INPUT",
    ])

    # Class instance variables holding unshareable values that workers read
    # during request dispatch. Made Ractor-shareable (deep-frozen) at boot.
    SHAREABLE_CLASS_IVARS.concat([
      ["ActiveSupport::Editor", :@editors],
      ["Warden::Strategies", :@strategies],
      # GlobalID.app: an UNFROZEN String set by global_id's railtie from
      # config.global_id.app. Worker Ractors cannot even READ an unfrozen
      # class ivar — so GlobalID.create (i.e. any ActiveJob argument
      # serialization: perform_later / deliver_later from a worker) dies with
      # "IsolationError: can not get unshareable values from instance
      # variables of classes/modules from non-main Ractors (@app from
      # GlobalID)" before GlobalID's own "An app is required" check even
      # runs. Deep-freeze the String so argument serialization works in
      # workers (shim TODO #5).
      ["GlobalID", :@app],
      # Row 75 (signed_id): the legacy signed-id rotation passes
      # `serializer: JSON` (stdlib) to the MessageVerifier, and JSON memoizes
      # its default-option Hashes as class ivars. Worker Ractors cannot even
      # READ those unfrozen ivars — verifier.generate/verify die with
      # "IsolationError: can not get unshareable values ... (@dump_default_options
      # from JSON)". Deep-freeze the two memo Hashes so the legacy JSON
      # serializer path works from any Ractor.
      ["JSON::Ext::Generator", :@skip],
      ["JSON", :@dump_default_options],
      ["JSON", :@load_default_options],
      ["JSON", :@generate_default_options],
      ["JSON", :@parse_default_options],
    ])

    # Public API: make Rails.application shareable across Ractors. Delegates
    # to `RactorRailsShim::AppShareabilizer.make_shareable!(app)` (extracted
    # Step 22.6, Issue #22). See `AppShareabilizer` for the full pipeline
    # contract (precompute → freeze ivars → warm routes → neutralize logger
    # → replace procs → replace locks → make_shareable → build fallback).
    #
    # WARNING: this MUTATES the app object graph in place (replaces ivars).
    # The app becomes read-only (frozen). Do NOT call if you intend to keep
    # mutating the app (e.g. development reloading). Production-only.
    #
    # Returns the shareable app. Raises on failure (e.g. if a Proc can't be
    # replaced — add the missing constant to shareable_constants first).
    def make_app_shareable!(app)
      AppShareabilizer.make_shareable!(app)
    end
  end
end