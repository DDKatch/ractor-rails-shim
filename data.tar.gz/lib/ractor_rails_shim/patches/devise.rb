# frozen_string_literal: true

# Patch for Devise (5.0). Two blockers for worker Ractors:
#
# 1. Devise::Controllers::UrlHelpers#generate_helpers! defines every helper
#    (session_path, new_session_path, user_password_path, ...) via
#    `define_method method do |resource_or_scope, *args| ... end` — a block
#    that captures the MAIN ractor's binding. Calling `session_path(...)` from
#    a worker raises "defined with an un-shareable Proc in a different Ractor".
#    Fix: redefine each helper via string eval (no captured binding); the body
#    replicates the original exactly, delegating to the underlying Rails route
#    helper via `context.send(method, *args)` (the real helpers are already
#    patched in action_dispatch.rb).
#
# 2. The helper body (and Devise::Mapping.find_scope!) reads `Devise.mappings`,
#    which reads the `@@mappings` class variable — unreadable from a worker
#    Ractor. Fix: snapshot `Devise.mappings` as a shareable Hash at prepare
#    time and have the patched `Devise.mappings` reader return it in workers
#    (skipping the main-ractor route reload).

module RactorRailsShim
  # Devise defines several top-level mutable Array/Hash constants
  # (TRUE_VALUES, FALSE_VALUES, NO_INPUT, ALL, CONTROLLERS, ROUTES,
  # STRATEGIES, URL_HELPERS) that are NOT frozen, hence non-shareable — a
  # worker Ractor raises "can not access non-shareable objects in constant
  # Devise::TRUE_VALUES ..." when it reads them (e.g. remember_me? ->
  # TRUE_VALUES). These are populated during boot and never mutated in
  # :ractor mode (frozen graph, no reloading), so deep-freeze + const_set
  # them shareable at prepare time.
  SHAREABLE_CONSTANTS.concat([
    "Devise::TRUE_VALUES",
    "Devise::FALSE_VALUES",
    "Devise::NO_INPUT",
    "Devise::ALL",
    "Devise::CONTROLLERS",
    "Devise::ROUTES",
    "Devise::STRATEGIES",
    "Devise::URL_HELPERS",
  ])

  class << self
    # Devise::FailureApp.call memoizes its Rack endpoint in a class-level ivar
    # (`@respond ||= action(:respond)`). A worker Ractor cannot set instance
    # variables on a shared class/module, so calling it raises "can not set
    # instance variables of classes/modules by non-main Ractors". Route the
    # memoized endpoint through IsolatedExecutionState (per-Ractor), so each
    # worker builds and caches its own copy without mutating the shared class.
    def _install_devise_failure_app_patch
      return if @devise_failure_app_patched
      @devise_failure_app_patched = true
      _register_patch :devise_failure_app, "5.0"
      return unless defined?(::Devise::FailureApp)
      ::Devise::FailureApp.singleton_class.module_eval <<-'RUBY', __FILE__, __LINE__ + 1
        def call(env)
          respond = RactorRailsShim.storage[:ractor_rails_shim_devise_failure_respond] ||= action(:respond)
          respond.call(env)
        end
      RUBY
      # Devise::FailureApp#relative_url_root reads `config.action_controller
      # .try(:relative_url_root)`. `config.action_controller` is a
      # Rails::Railtie::Configuration whose `relative_url_root` is NOT a real
      # method, so `try` triggers `method_missing`, which reads the `@@options`
      # class variable — unreadable from a worker Ractor. `Rails.application
      # .config.relative_url_root` IS a real method on
      # Rails::Application::Configuration (no method_missing, no class var), so
      # use just that; for the common case (no relative root) it returns nil.
      if defined?(::Devise::FailureApp)
        ::Devise::FailureApp.module_eval <<-RUBY, __FILE__, __LINE__ + 1
          def relative_url_root
            @relative_url_root ||= Rails.application.config.relative_url_root
          end
        RUBY
      end
    end

    # Devise::Models::Authenticatable::ClassMethods#devise_parameter_filter
    # memoizes `@devise_parameter_filter ||= Devise::ParameterFilter.new(...)`
    # on the MODEL CLASS. A worker Ractor cannot set an instance variable on a
    # shared class/module, so calling it raises "can not set instance variables
    # of classes/modules by non-main Ractors". Route the memoized filter through
    # IsolatedExecutionState (per-Ractor), keyed by the (shared, stable) class
    # object_id. `case_insensitive_keys` / `strip_whitespace_keys` are
    # class_attribute values the shim already routes through IES, so they read
    # fine in a worker.
    def _install_devise_authenticatable_patch
      return if @devise_authenticatable_patched
      @devise_authenticatable_patched = true
      _register_patch :devise_authenticatable, "5.0"
      return unless defined?(::Devise::Models::Authenticatable::ClassMethods)
      ::Devise::Models::Authenticatable::ClassMethods.module_eval <<-RUBY, __FILE__, __LINE__ + 1
        def devise_parameter_filter
          key = :"ractor_rails_shim_devise_param_filter_\#{object_id}"
          v = RactorRailsShim.storage[key]
          return v unless v.nil?
          return nil if RactorRailsShim.storage.key?(key)
          f = Devise::ParameterFilter.new(case_insensitive_keys, strip_whitespace_keys)
          RactorRailsShim.storage[key] = f
          f
        end
      RUBY
    end

    # Devise.mailer reads `@@mailer_ref` (a class variable) which raises
    # IsolationError from a worker Ractor. The `@@mailer_ref` holds a
    # Devise::Getter instance (which is shareable — it only holds a String
    # class name). Capture it at prepare time and have workers read the
    # captured shareable copy instead of the cvar.
    # Also patch `Devise.parent_mailer` and `Devise.mailer_sender` which read
    # `@@parent_mailer` / `@@mailer_sender` cvars — these are read when
    # building mailer messages.
    def _install_devise_mailer_patch
      return if @devise_mailer_patched
      @devise_mailer_patched = true
      _register_patch :devise_mailer, "5.0"
      return unless defined?(::Devise)

      # Capture the Getter instance (it holds a String — shareable).
      mailer_ref = nil
      begin
        mailer_ref = ::Devise.class_variable_get(:@@mailer_ref)
      rescue StandardError
        nil
      end
      if mailer_ref
        RactorRailsShim.const_set(:SHAREABLE_DEVISE_MAILER_REF,
          Ractor.make_shareable(mailer_ref))
      end

      ::Devise.singleton_class.module_eval <<-'RUBY', __FILE__, __LINE__ + 1
        def mailer
          if ::Ractor.main?
            @@mailer_ref.get
          else
            ref = ::RactorRailsShim::SHAREABLE_DEVISE_MAILER_REF
            ref ? ref.get : ::Devise::Mailer
          end
        end
      RUBY
    end

    def _install_devise_url_helpers_patch
      return if @devise_url_helpers_patched
      @devise_url_helpers_patched = true
      _register_patch :devise_url_helpers, "5.0"
      # Generate DeviseMappingSnapshot predicates from Devise::MODULES now that
      # Devise is loaded. Replaces the hardcoded fallback list with the actual
      # module set (incl. any third-party gems added at boot). No-op if
      # Devise::MODULES isn't defined.
      DeviseMappingSnapshot.generate_predicates_from_devise_modules!
      return unless defined?(::Devise::Controllers::UrlHelpers)

      mod = ::Devise::Controllers::UrlHelpers

      # Patch Devise.mappings FIRST (before the snapshot below) so every
      # subsequent read — including the snapshot — does NOT trigger a route
      # reload. Routes are fully drawn by Rails.application.initialize! before
      # prepare_for_ractors! runs, so @@mappings is already populated in main;
      # workers read the shareable snapshot instead. The ORIGINAL
      # Devise.mappings calls reload_routes_unless_loaded, which during
      # prepare collapses the RouteSet to a single railtie route (rails/info)
      # that then gets frozen into the shared app graph — breaking routing for
      # every worker Ractor.
      if defined?(::Devise) && ::Devise.respond_to?(:mappings)
        ::Devise.singleton_class.module_eval <<-RUBY, __FILE__, __LINE__ + 1
          def mappings
            return RactorRailsShim::DEVISE_MAPPINGS if !Ractor.main? && RactorRailsShim.const_defined?(:DEVISE_MAPPINGS)
            ::Devise.class_variable_get(:@@mappings)
          end
        RUBY
      end

      # Capture a shareable snapshot of Devise.mappings in MAIN (after routes
      # are drawn). The real Mapping objects hold an unshareable failure-app
      # lambda and a default-proc Hash, so we can't share them directly; build
      # a DeviseMappingSnapshot per scope (see make_shareable.rb). Workers read
      # this via the patched Devise.mappings reader.
      if Ractor.main? && defined?(::Devise)
        begin
          h = ::Devise.mappings
          snap = {}
          h.each { |scope, mapping| snap[scope] = _devise_mapping_snapshot(mapping) }
          snap = _swallow("make devise mappings shareable") { Ractor.make_shareable(snap) }
          const_set(:DEVISE_MAPPINGS, snap) if snap
        rescue StandardError
          nil
        end
      end

      # Redefine each generated helper via string eval (no captured binding).
      # Replicate the EXACT body of Devise::Controllers::UrlHelpers.generate_helpers!
      # (lib/devise/controllers/url_helpers.rb): the helper does NOT call the
      # alias method on the context — it reconstructs the REAL route helper name
      # from `action` + `scope` + `module_name` (e.g. alias `session_path` ->
      # real `user_session_path`) and sends THAT to the context. Bake in
      # `action`/`module_name`/`path_or_url` as literals; `scope` is resolved
      # per-call from the argument, so interpolate it at runtime (\\#{scope}).
      routes = ::Devise::URL_HELPERS.slice(*(::Devise.mappings.values.map(&:used_helpers).flatten.uniq))
      routes.each do |module_name, actions|
        [:path, :url].each do |path_or_url|
          actions.each do |action|
            action_prefix = action ? "#{action}_" : ""
            method = :"#{action_prefix}#{module_name}_#{path_or_url}"
            mod.module_eval <<-RUBY, __FILE__, __LINE__ + 1
              def #{method}(resource_or_scope, *args)
                scope = Devise::Mapping.find_scope!(resource_or_scope)
                router_name = Devise.mappings[scope].router_name
                context = router_name ? send(router_name) : _devise_route_context
                context.send("#{action_prefix}\#{scope}_#{module_name}_#{path_or_url}", *args)
              end
            RUBY
          end
        end
      end
    end
  end
end
